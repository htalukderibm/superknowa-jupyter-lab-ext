from setuptools import find_packages


__import__('setuptools').setup(name='superknowa-ext-byom-backend',
    version='1.0.0',
    description='Superknowa bring your BYOM',
    long_description='A Superknowa JupyterLab extension.',
    author='Himadri Talukder',
    author_email='htalukder@ibm.com',
    packages=find_packages(),
    keywords=['superknowa byom', 'superknowa', 'IBM Superknowa'])
