import json
from jupyter_core.paths import jupyter_config_path
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import requests
import tornado
import time
import os
import os.path as osp
from threading import Timer

#### ----------- schematics class --------------------------------------------------
from ibm_schematics.schematics_v1 import SchematicsV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

class Schematics:
    
    user_sttings_file_name = ".superknowa_boym_settings.json"
    workspace_name = "superknowa_byom_workspace_v2"

    def __init__(self,ibm_iam_token):
        self.ibm_iam_token = ibm_iam_token
        authenticator = IAMAuthenticator(self.ibm_iam_token)
        service = SchematicsV1(authenticator=authenticator)
        service.set_service_url('https://schematics.cloud.ibm.com')
        self.schematic_service = service
    
    def pjoin(self, *args):
        """Join paths to create a real path.
        """
        return osp.realpath(osp.join(*args))
    
    def get_user_settings_dir(self):
        """Get the configured JupyterLab user settings directory.
           /.jupyter/lab/user-settings/ 
        """
        settings_dir = self.pjoin(
            jupyter_config_path()[0]
        )
        return osp.realpath(settings_dir)

    def get_workspace_list(self):
        result = self.schematic_service.list_workspaces().get_result()
        return result
    
    def get_workspace_by_id(self, w_id):
        workspace_response = self.schematic_service.get_workspace(
            w_id=w_id
        ).get_result()
        return workspace_response

    def create_schematic_workspace(self,data: dict):
        vpc_vsi_profile_name = data["vpc_vsi_profile_name"]
        vpc_vsi_image_name = data["vpc_vsi_image_name"]
        region = data["region"]
        zone = data["zone"]
        ssh_key_name = data["ssh_key_name"]
        githubPAT = data["githubPAT"]

        template_source_data_request_model = {}
        template_source_data_request_model['folder'] = '.'
        template_source_data_request_model['compact'] = True
        template_source_data_request_model['type'] = 'terraform_v1.5'
        template_source_data_request_model['variablestore'] = [
                {
                    "name": "resource_group",
                    "value": "poc",
                    "type": "string"
                },
                {
                    "name": "vpc",
                    "value": "byom-dev",
                    "type": "string"
                },
                {
                    "name": "keys",
                    "value": f"[\"{ssh_key_name}\"]",
                    "type": "list(string)"
                },
                {
                    "name": "region",
                    "value": region,
                    "type": "string"
                },
                {
                    "name": "zone",
                    "value": zone,
                    "type": "string"
                },
                {
                    "name": "vpc_vsi_image_name",
                    "value": vpc_vsi_image_name,
                    "type": "string"
                },
                {
                    "name": "vpc_vsi_profile_name",
                    "value": vpc_vsi_profile_name,
                    "type": "string"
                }
        ]

        template_repo_request_model = {}
        template_repo_request_model['url'] = 'https://github.ibm.com/hcbt/SuperKnowa-BYOM/tree/main/terraform'
        #template_repo_request_model['branch'] = 'main'
        workspace_response = self.schematic_service.create_workspace(
            description="superknowa bring your own model schematic workspace", 
            name=self.workspace_name,
            template_data=[template_source_data_request_model],
            template_repo=template_repo_request_model,
            type=['terraform_v1.5'],
            location=region,
            tags=['superknowa:byom'],
            x_github_token=githubPAT
        ).get_result()

        ## Saving the workspace output to a file
        # Serializing json
        """
        settings_object = {
            "user_data": {
                "ibm_iam_token": self.ibm_iam_token,
                "git_pat": githubPAT
            },
            "workspace_data": workspace_response
        }
        """
        json_object = json.dumps(workspace_response, indent=4)
    
        user_settings_path = self.get_user_settings_dir()
        # Writing to sample.json
        with open(f"{user_settings_path}/{self.user_sttings_file_name}", "w+") as outfile:
            outfile.write(json_object)

        return workspace_response

    """
    This function returns the existing workspace setting and details
    """
    def get_user_settings(self):
        
        user_settings_path = self.get_user_settings_dir()
        file_location = f"{user_settings_path}/{self.user_sttings_file_name}"

        if(os.path.exists(file_location) is False):
            return {
                'id': None
            }

        with open(file_location, "r") as openfile:
            json_object = json.load(openfile)
        
        return json_object

    def get_token(self):
        # Set the URL for the IBM Cloud IAM token endpoint
        url = 'https://iam.cloud.ibm.com/identity/token'

        # Set the headers for the POST request
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        # Set the data for the POST request
        data = {
            'grant_type': 'urn:ibm:params:oauth:grant-type:apikey',
            'apikey': self.ibm_iam_token
        }

        # Make the POST request
        response = requests.post(url, headers=headers, data=data, auth=('bx', 'bx'))
        return response.json()
    
    def apply_script(self,w_id):
        ## time.sleep(120)
        print("started applying the terraform script........")
        refresh_token = self.get_token()['refresh_token']
        response = self.schematic_service.apply_workspace_command(w_id=w_id, refresh_token=refresh_token)
        print("done applying the terraform script........")
        return response
    
    def get_server_details(self, w_id):
        output = self.schematic_service.get_workspace_outputs(w_id=w_id)
        return output
    
    def destroy_script(self,w_id):
        refresh_token = self.get_token()['refresh_token']
        response = self.schematic_service.delete_workspace(w_id=w_id, refresh_token=refresh_token, destroy_resources=True)
        return response

    def create_and_apply(self,data: dict):
        workspace = self.create_schematic_workspace(data=data)
        w_id = workspace["id"]
        if(id is not None):
            Timer(300,lambda: self.apply_script(w_id=w_id)).start()
        return workspace

### ------------ schematics class --------------------------------------------------

class RouteHandler(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def get(self):
        sc = Schematics(ibm_iam_token=None)
        object = sc.get_user_settings()
        self.finish(json.dumps(object))

class RouteHandlerGetWorkspaceStatus(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):
        try:
            data = json.loads(self.request.body)
            ibm_iam_token = data["ibm_iam_token"]
            sc = Schematics(ibm_iam_token)
            result = sc.get_user_settings()
            if 'id' in result:
                workspace_id = result['id']
                workspace = sc.get_workspace_by_id(w_id=workspace_id)
                self.finish(json.dumps({"status": "success", "message": "workspace details", "data": workspace}))
            else:
                self.finish(json.dumps({"status": "error", "message": "Workspace is not exist."}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"status": "error", "message": "Error in retreiving status", "data": str(e)}))

class RouteServerDetailsSchematicWorkspace(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):
        try:
            data = json.loads(self.request.body)
            ibm_iam_token = data["ibm_iam_token"]
            sc = Schematics(ibm_iam_token)
            result = sc.get_user_settings()

            if 'id' in result:
                workspace_id = result['id']
                server_details = sc.get_server_details(w_id=workspace_id)
                print("============================================")
                print(server_details)
                print("============================================")
                self.finish(json.dumps({"status": "success", "message": "server details", "data": server_details}))
            else:
                self.finish(json.dumps({"status": "error", "message": "Server not found", "data": {}}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"status": "error", "message": "Invalid JSON data", "error": str(e)}))

class RouteCreateSchematicWorkspace(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):
        try:
            data = json.loads(self.request.body)
            ibm_iam_token = data["ibm_iam_token"]
            
            sc = Schematics(ibm_iam_token)
            result = sc.get_user_settings()
            if 'id' in result:
                workspace_id = result['id']
                try:
                    workspace = sc.get_workspace_by_id(w_id=workspace_id)
                    self.finish(json.dumps({"status": "success", "type": "existing", "message": "workspace details", "data": workspace}))
                    return
                except:
                    print("workspace not found!!")

            response = sc.create_and_apply(data=data)
            self.finish(json.dumps({"status": "success","type": "new", "message": "created successfully", "data": response}))
        except json.JSONDecodeError as e:
            self.set_status(400)
            self.finish(json.dumps({"status": "error", "type": "unknown", "message": "Invalid JSON data", "error": str(e)}))

class RouteDeleteSchematicWorkspace(APIHandler):
    # The following decorator should be present on all verb methods (head, get, post,
    # patch, put, delete, options) to ensure only authorized user can request the
    # Jupyter server
    @tornado.web.authenticated
    def post(self):
        try:
            data = json.loads(self.request.body)
            ibm_iam_token = data["ibm_iam_token"]
            
            sc = Schematics(ibm_iam_token)
            result = sc.get_user_settings()
            if 'id' in result:
                workspace_id = result['id']
                response = sc.destroy_script(w_id=workspace_id)
                self.finish(json.dumps({"status": "success", "type": "delete", "message": "workspace delete", "data": "destroying"}))
            else:
                self.finish(json.dumps({"status": "error", "type": "delete", "message": "There is no workspace exist to delete", "error": str(e)}))
        except json.JSONDecodeError as e:
            self.finish(json.dumps({"status": "error", "type": "delete", "message": "Server error", "data": str(e)}))

def setup_handlers(web_app):
    host_pattern = ".*$"

    base_url = web_app.settings["base_url"]
    route_pattern = url_path_join(base_url, "superknowa-ext-byom", "test")
    route_pattern_server_details = url_path_join(base_url, "superknowa-ext-byom", "serverstatus")
    route_pattern_wcreate = url_path_join(base_url, "superknowa-ext-byom", "workspace")
    route_pattern_wdelete = url_path_join(base_url, "superknowa-ext-byom", "wdelete")
    route_pattern_getworkspacebystatus = url_path_join(base_url, "superknowa-ext-byom", "wstatus")
    
    handlers = [
        (route_pattern, RouteHandler), 
        (route_pattern_server_details, RouteServerDetailsSchematicWorkspace),
        (route_pattern_wcreate, RouteCreateSchematicWorkspace),
        (route_pattern_getworkspacebystatus, RouteHandlerGetWorkspaceStatus),
        (route_pattern_wdelete, RouteDeleteSchematicWorkspace)
        ]
    web_app.add_handlers(host_pattern, handlers)
