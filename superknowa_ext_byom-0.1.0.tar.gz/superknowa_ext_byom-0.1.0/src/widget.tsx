import { ReactWidget } from '@jupyterlab/ui-components';
import {
  Box,
  Typography,
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  Button,
  MenuItem,
  Select,
  TextField,
  Alert,
  Card,
  CardContent,
  CardActions,
  CardHeader,
  IconButton,
  Tooltip,
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  LinearProgress,
  Link,
  FormHelperText,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Modal,
  CircularProgress
} from '@mui/material';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Visibility from '@mui/icons-material/Visibility';
import React, { useEffect } from 'react';
import IBMIcon from './IBMIcon';
import RefreshOutlinedIcon from '@mui/icons-material/RefreshOutlined';
import RemoveCircleOutlineOutlinedIcon from '@mui/icons-material/RemoveCircleOutlineOutlined';
import StorageOutlinedIcon from '@mui/icons-material/StorageOutlined';
import CreateOutlinedIcon from '@mui/icons-material/CreateOutlined';
import LoopOutlinedIcon from '@mui/icons-material/LoopOutlined';
import SyncDisabledOutlinedIcon from '@mui/icons-material/SyncDisabledOutlined';
import CloseIcon from '@mui/icons-material/Close';
import { useFormik } from 'formik';
import * as yup from 'yup';
import {
  checkServerStatus,
  checkWorkspaceStatus,
  get_server_state,
  get_workspace_state,
  provisionWorkspace,
  region_zone,
  requestDeleteWorkspace,
  parse_workspace_name,
  checkServerActivity,
  gpu_profiles
} from './api/schematic';

/**
 * React component for a counter.
 *
 * @returns The React component
 */
const GPUProvisionComponent = (): JSX.Element => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [showPat, setShowPat] = React.useState(false);
  const [ibm_iam_token, setIbm_iam_token] = React.useState('');

  const [server_details, setServer_details] = React.useState(get_server_state);

  const [checkStatusInProgress, setCheckStatusInProgress] =
    React.useState(false);

  const [activityLogModal, setActivityLogModal] = React.useState(false);
  const [activityLogContent, setActivityLogContent] = React.useState('');

  const [submitStatus, setSubmitStatus] = React.useState({
    status: '',
    message: ''
  });

  const handleClickShowPassword = () => setShowPassword(show => !show);
  const handleClickShowGithubPAT = () => setShowPat(show => !show);

  const [openRemoveWorkspaceAgree, setOpenRemoveWorkspaceAgree] =
    React.useState(false);

  const handleRemoveWorkspaceOpen = () => {
    setOpenRemoveWorkspaceAgree(true);
  };

  const handleRemoveWorkspaceClose = () => {
    setOpenRemoveWorkspaceAgree(false);
  };

  const [openCreateWorkspaceAgree, setOpenCreateWorkspaceAgree] =
    React.useState(false);

  const handleCreateWorkspaceOpen = () => {
    setOpenCreateWorkspaceAgree(true);
  };

  const handleCreateWorkspaceClose = () => {
    setOpenCreateWorkspaceAgree(false);
  };

  const [workspaceStatusResponse, setWorkspaceStatusResponse] =
    React.useState(get_workspace_state);

  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const handleMouseDownShowPat = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const validationSchema = yup.object({
    workspace_name: yup
      .string()
      .required('Workspace name is required')
      .matches(/^(\S+$)/g, 'Workspace name can not contain only blankspaces')
      .matches(/^[^!@#$%^&*+=<>:;|~_-]*$/, {
        message: 'Workspace name can not contain any symbols'
      })
      .matches(/^[a-z]+$/, {
        message: 'Lower case character only'
      }),
    ibm_iam_token: yup.string().required('IBM API key is required'),
    githubPAT: yup.string().required('Github API key required'),
    ssh_key_name: yup
      .string()
      .required(
        'Please enter a valid ssh key based on the region you select, otherwise you will not be able to access the VM after it provisioned.'
      ),
    vpc_vsi_profile_name: yup.string().required('Please select a GPU profile'),
    region: yup.string().required('Please select a region'),
    zone: yup.string().required('Please select a zone'),
    resource_group_name: yup.string().required('Resource group is required'),
    jupyter_lab_image: yup
      .string()
      .required('Jupyter image name is required')
      .matches(
        /^(quay\.io\/[a-zA-Z0-9]*\/[a-zA-Z0-9-_]*:[a-zA-Z0-9-_.]*)/g,
        'Please enter a valid jupyter lab image. A valid jupyter image format is quay.io/<REPOSITORY>/<IMAGE>:<TAG>'
      )
  });

  const formik = useFormik({
    initialValues: {
      workspace_name: parse_workspace_name(workspaceStatusResponse.name),
      ssh_key_name: '',
      ibm_iam_token: '',
      githubPAT: '',
      vpc_vsi_image_name: 'ibm-ubuntu-22-04-3-minimal-amd64-1',
      vpc_vsi_profile_name: 'gx3-16x80x1l4',
      resource_group_name: 'Default',
      jupyter_lab_image: 'quay.io/jupyter/datascience-notebook:python-3.11',
      zone: 'us-south-1',
      region: 'us-south'
    },
    validationSchema: validationSchema,
    onSubmit: values => {
      handleCreateWorkspaceOpen();
    }
  });

  const handleWorkspaceStatus = async () => {
    // reset the progress bar and submit status
    setCheckStatusInProgress(true);
    setSubmitStatus({
      status: '',
      message: ''
    });
    await checkWorkspaceStatus(
      ibm_iam_token,
      setCheckStatusInProgress,
      setSubmitStatus,
      setWorkspaceStatusResponse,
      setServer_details
    );
    // set the progress bar and submit status based on the response
  };

  const handleServerStatus = async () => {
    // reset the progress bar and submit status
    setCheckStatusInProgress(true);
    setSubmitStatus({
      status: '',
      message: ''
    });
    await checkServerStatus(
      ibm_iam_token,
      setCheckStatusInProgress,
      setSubmitStatus,
      setServer_details
    );
  };

  const handleServerActivityLog = async () => {
    // reset the progress bar and submit status
    setCheckStatusInProgress(true);
    setSubmitStatus({
      status: '',
      message: ''
    });
    await checkServerActivity(
      ibm_iam_token,
      setCheckStatusInProgress,
      setSubmitStatus,
      setActivityLogContent,
      setActivityLogModal
    );
  };

  const handleDeleteWorkspace = async () => {
    // reset the progress bar and submit status
    setCheckStatusInProgress(true);
    handleRemoveWorkspaceClose();
    setSubmitStatus({
      status: '',
      message: ''
    });
    await requestDeleteWorkspace(
      ibm_iam_token,
      setCheckStatusInProgress,
      setSubmitStatus
    );
  };

  const handleProvisionWorkspace = async () => {
    // reset the progress bar and submit status
    handleCreateWorkspaceClose();
    setCheckStatusInProgress(true);
    setSubmitStatus({
      status: '',
      message: ''
    });
    try {
      await provisionWorkspace(
        formik.values,
        setCheckStatusInProgress,
        setSubmitStatus,
        setWorkspaceStatusResponse,
        setProvisioning
      );
    } catch {
      console.log('error in calling api');
      /* empty */
    }
  };

  const [customizeSettings, setCustomizeSettings] = React.useState(false);

  const [autoRefresh, setAutoRefresh] = React.useState(false);

  const [provisioning, setProvisioning] = React.useState(false);
  //const [removing, setRemoving] = React.useState(false);
  //const [updating, setUpdating] = React.useState(false);

  const handleCustomizeSettings = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setCustomizeSettings(event.target.checked);
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (autoRefresh && ibm_iam_token) {
        handleWorkspaceStatus();
      }
    }, 1 * 60 * 1000);

    // Cleanup function to clear interval when component unmounts
    return () => clearInterval(intervalId);
  }, [autoRefresh, ibm_iam_token]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (provisioning && ibm_iam_token) {
        if (
          workspaceStatusResponse.status === 'ACTIVE' ||
          workspaceStatusResponse.status === 'FAILED'
        ) {
          console.log('active status detected');
          setProvisioning(false);
        } else {
          handleWorkspaceStatus();
        }
      }

    }, 1 * 65 * 1000);

    // Cleanup function to clear interval when component unmounts
    return () => clearInterval(intervalId);
  }, [provisioning, ibm_iam_token, workspaceStatusResponse]);

  const startStopAutoRefresh = (event: React.ChangeEvent<HTMLInputElement>) => {
    setAutoRefresh(event.target.checked);
  };

  return (
    <Box>
      <Box display={'flex'} justifyContent={'space-between'}>
        <Box display={'flex'} justifyContent={'flex-start'}>
          <Typography>
            <IBMIcon />
          </Typography>
          <Typography
            mt={'12px'}
            ml={'5px'}
            variant="h6"
            height={'30px'}
            noWrap
            sx={{
              display: { xs: 'none', md: 'flex' },
              textDecoration: 'none'
            }}
          >
            Ecosystem Engineering
          </Typography>
        </Box>
        <Typography
          mt={'12px'}
          ml={'5px'}
          variant="h6"
          height={'30px'}
          noWrap
          sx={{
            display: { xs: 'none', md: 'flex' },
            textDecoration: 'none'
          }}
        >
          BYOM Starter
        </Typography>
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                color="success"
                checked={autoRefresh}
                onChange={startStopAutoRefresh}
                icon={<SyncDisabledOutlinedIcon />}
                checkedIcon={<LoopOutlinedIcon />}
              />
            }
            label="Auto refresh"
          />
        </FormGroup>
      </Box>
      <Box
        display={'flex'}
        mt={'50px'}
        flexDirection={'row'}
        alignContent={'center'}
        justifyContent={'center'}
      >
        {submitStatus.status === 'success' && (
          <Alert
            sx={{ marginBottom: '20px' }}
            variant="outlined"
            severity="success"
          >
            {submitStatus.message}
          </Alert>
        )}
        {submitStatus.status === 'error' && (
          <Alert
            sx={{ marginBottom: '20px' }}
            variant="outlined"
            severity="error"
          >
            {submitStatus.message}
          </Alert>
        )}
      </Box>
      {checkStatusInProgress && (
        <Box
          display={'flex'}
          flexDirection={'row'}
          alignContent={'center'}
          justifyContent={'center'}
          ml={'50px'}
          mr={'50px'}
        >
          <LinearProgress sx={{ width: '100%' }} color="success" />
        </Box>
      )}
      <Box
        display={'flex'}
        ml={'50px'}
        mr={'50px'}
        flexDirection={'row'}
        justifyContent={'space-between'}
      >
        <Card sx={{ width: '49%' }}>
          <CardHeader
            titleTypographyProps={{ variant: 'subtitle2' }}
            title="Provision a GPU server in IBM Cloud for training, inference, and deploying an LLM model."
          />
          <form onSubmit={formik.handleSubmit}>
            <CardContent>
              <Paper style={{ padding: '10px' }}>
                <TextField
                  margin="dense"
                  sx={{
                    width: '60ch',
                    marginBottom: '10px'
                  }}
                  id="workspace_name"
                  name="workspace_name"
                  label="Workspace name"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.workspace_name}
                  inputProps={{
                    style: {
                      height: 10
                    }
                  }}
                  error={
                    formik.touched.workspace_name &&
                    Boolean(formik.errors.workspace_name)
                  }
                />
                <Box>
                  {formik.errors.workspace_name &&
                    formik.touched.workspace_name && (
                      <FormHelperText error={true}>
                        {formik.errors.workspace_name.toString()}
                      </FormHelperText>
                    )}
                </Box>
                <FormControl sx={{ width: '60ch' }} variant="outlined">
                  <InputLabel htmlFor="ibm_iam_token" sx={{ fontSize: '14px' }}>
                    IBM Api key
                  </InputLabel>
                  <OutlinedInput
                    margin="dense"
                    sx={{ height: '40px' }}
                    id="ibm_iam_token"
                    type={showPassword ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          onMouseDown={handleMouseDownPassword}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="Api Key"
                    value={formik.values.ibm_iam_token}
                    onChange={e => {
                      setIbm_iam_token(e.target.value);
                      formik.handleChange(e);
                    }}
                    onBlur={formik.handleBlur}
                    name="ibm_iam_token"
                  />
                  {formik.errors.ibm_iam_token &&
                    formik.touched.ibm_iam_token && (
                      <FormHelperText error={true}>
                        {formik.errors.ibm_iam_token}
                      </FormHelperText>
                    )}
                </FormControl>
                <FormControl
                  sx={{ width: '60ch', mt: '10px' }}
                  variant="outlined"
                >
                  <InputLabel htmlFor="githubPAT" sx={{ fontSize: '14px' }}>
                    Github access token
                  </InputLabel>
                  <OutlinedInput
                    margin="dense"
                    sx={{ height: '40px' }}
                    id="githubPAT"
                    name="githubPAT"
                    type={showPat ? 'text' : 'password'}
                    endAdornment={
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleClickShowGithubPAT}
                          onMouseDown={handleMouseDownShowPat}
                          edge="end"
                        >
                          {showPat ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    }
                    label="Github access token"
                    value={formik.values.githubPAT}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.githubPAT && formik.touched.githubPAT && (
                    <FormHelperText error={true}>
                      {formik.errors.githubPAT}
                    </FormHelperText>
                  )}
                </FormControl>
                <TextField
                  margin="dense"
                  sx={{
                    width: '60ch',
                    marginTop: '10px'
                  }}
                  id="ssh_key_name"
                  name="ssh_key_name"
                  label="ssh key name"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.ssh_key_name}
                  inputProps={{
                    style: {
                      height: 10
                    }
                  }}
                  error={
                    formik.touched.ssh_key_name &&
                    Boolean(formik.errors.ssh_key_name)
                  }
                />
                <Box>
                  {formik.errors.ssh_key_name &&
                    formik.touched.ssh_key_name && (
                      <FormHelperText error={true}>
                        {formik.errors.ssh_key_name}
                      </FormHelperText>
                    )}
                </Box>
              </Paper>
              {/** customize default settings checkbox */}
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      color="success"
                      checked={customizeSettings}
                      onChange={handleCustomizeSettings}
                    />
                  }
                  label="Customize default settings"
                />
              </FormGroup>
              {/** customize default settings checkbox */}
              <Paper
                style={{
                  padding: '10px',
                  display: customizeSettings ? 'block' : 'none'
                }}
              >
                <Box
                  display={'flex'}
                  ml={'5px'}
                  mr={'5px'}
                  flexDirection={'column'}
                >
                  <Box
                    display={'flex'}
                    flexDirection={'row'}
                    marginTop={'15px'}
                  >
                    <FormControl sx={{ minWidth: 120 }}>
                      <InputLabel htmlFor="region" sx={{ fontSize: '14px' }}>
                        Region
                      </InputLabel>
                      <Select
                        sx={{ height: '40px', fontSize: '14px' }}
                        native
                        id="region"
                        name="region"
                        label="Region"
                        onChange={e => {
                          e.preventDefault();
                          formik.handleChange(e);
                          formik.setFieldValue('zone', '');
                        }}
                        onBlur={formik.handleBlur}
                        value={formik.values.region}
                      >
                        <option aria-label="None" value="" />
                        {region_zone.map((reg, _inx) => {
                          return (
                            <optgroup key={_inx} label={reg.label}>
                              {reg.region.map((reg_name, _rinx) => {
                                return (
                                  <option key={_rinx} value={reg_name.value}>
                                    {reg_name.label}
                                  </option>
                                );
                              })}
                            </optgroup>
                          );
                        })}
                      </Select>
                      {formik.errors.region && formik.touched.region && (
                        <div>{formik.errors.region}</div>
                      )}
                    </FormControl>
                    <FormControl
                      sx={{
                        width: '150px',
                        marginLeft: '10px',
                        marginRight: '10px'
                      }}
                      variant="outlined"
                    >
                      <InputLabel
                        id="zone-select-label"
                        sx={{ fontSize: '14px' }}
                      >
                        Zone
                      </InputLabel>
                      <Select
                        sx={{ height: '40px', fontSize: '14px' }}
                        labelId="zone-select-label"
                        id="zone"
                        name="zone"
                        label="Zone"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.zone}
                      >
                        {region_zone
                          .flatMap(reg => reg.region)
                          .filter(zn => zn.value === formik.values.region)
                          .flatMap(item => item.zone)
                          .map((fzone, _inx) => {
                            return (
                              <MenuItem key={_inx} value={fzone}>
                                {fzone}
                              </MenuItem>
                            );
                          })}
                      </Select>
                      {formik.errors.zone && formik.touched.zone && (
                        <FormHelperText error={true}>
                          {formik.errors.zone}
                        </FormHelperText>
                      )}
                    </FormControl>
                  </Box>
                  <FormControl
                    sx={{ width: '50ch', marginTop: '15px' }}
                    variant="outlined"
                  >
                    <InputLabel
                      id="image-vsi-select-label"
                      sx={{ fontSize: '14px' }}
                    >
                      OS Profile
                    </InputLabel>
                    <Select
                      sx={{ height: '40px', fontSize: '14px' }}
                      labelId="image-vsi-select-label"
                      id="vpc_vsi_image_name"
                      name="vpc_vsi_image_name"
                      label="OS Profile"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.vpc_vsi_image_name}
                    >
                      <MenuItem value={'ibm-ubuntu-22-04-3-minimal-amd64-1'}>
                        ibm-ubuntu-22-04-3-minimal-amd64-1
                      </MenuItem>
                      <MenuItem value={'ibm-ubuntu-22-04-3-minimal-amd64-2'}>
                        ibm-ubuntu-22-04-3-minimal-amd64-2
                      </MenuItem>
                      <MenuItem value={'ibm-ubuntu-20-04-6-minimal-amd64-3'}>
                        ibm-ubuntu-20-04-6-minimal-amd64-3
                      </MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl
                    sx={{ width: '50ch', marginTop: '15px' }}
                    variant="outlined"
                  >
                    <InputLabel
                      id="demo-simple-select-label"
                      sx={{ fontSize: '14px' }}
                    >
                      GPU Profile
                    </InputLabel>
                    <Select
                      native
                      sx={{ height: '40px', fontSize: '14px' }}
                      labelId="demo-simple-select-label"
                      id="vpc_vsi_profile_name"
                      name="vpc_vsi_profile_name"
                      label="GPU Profile"
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                      value={formik.values.vpc_vsi_profile_name}
                    >
                      {gpu_profiles.map((profile, _inx) => {
                        return (
                          <optgroup key={_inx} label={profile.label}>
                            {profile.profiles.map((item, _rinx) => {
                              return (
                                <option key={_rinx} value={item.value}>
                                  {item.value}
                                </option>
                              );
                            })}
                          </optgroup>
                        );
                      })}
                    </Select>
                  </FormControl>
                  <TextField
                    margin="dense"
                    sx={{
                      width: '30ch',
                      marginTop: '15px'
                    }}
                    id="resource_group_name"
                    name="resource_group_name"
                    label="Resource Group"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.resource_group_name}
                    inputProps={{
                      style: {
                        height: 10
                      }
                    }}
                    error={
                      formik.touched.resource_group_name &&
                      Boolean(formik.errors.resource_group_name)
                    }
                  />
                  <Box>
                    {formik.errors.resource_group_name &&
                      formik.touched.resource_group_name && (
                        <FormHelperText error={true}>
                          {formik.errors.resource_group_name}
                        </FormHelperText>
                      )}
                  </Box>
                  <TextField
                    margin="dense"
                    sx={{
                      width: '60ch',
                      marginTop: '15px'
                    }}
                    id="jupyter_lab_image"
                    name="jupyter_lab_image"
                    label="Jupyter Lab Image"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.jupyter_lab_image}
                    inputProps={{
                      style: {
                        height: 10
                      }
                    }}
                    error={
                      formik.touched.jupyter_lab_image &&
                      Boolean(formik.errors.jupyter_lab_image)
                    }
                  />
                  <Box>
                    {formik.errors.jupyter_lab_image &&
                      formik.touched.jupyter_lab_image && (
                        <FormHelperText error={true}>
                          {formik.errors.jupyter_lab_image}
                        </FormHelperText>
                      )}
                  </Box>
                </Box>
              </Paper>
            </CardContent>
            <CardActions>
              <Box marginTop={'15px'} display={'flex'} flexDirection={'row'}>
                {!workspaceStatusResponse.id && (
                  <Tooltip title="Deploy a GPU server instance">
                    <Button
                      disabled={checkStatusInProgress || provisioning}
                      variant="outlined"
                      size="small"
                      sx={{
                        fontSize: '14px',
                        mr: '10px',
                        textTransform: 'none'
                      }}
                      type="submit"
                      color="success"
                      startIcon={<CreateOutlinedIcon />}
                    >
                      Provision
                    </Button>
                  </Tooltip>
                )}
                {workspaceStatusResponse.id && (
                  <>
                    <Tooltip title="Update the GPU server instance">
                      <Button
                        disabled={checkStatusInProgress || provisioning}
                        variant="outlined"
                        size="small"
                        sx={{
                          fontSize: '14px',
                          mr: '10px',
                          textTransform: 'none'
                        }}
                        type="submit"
                        color="success"
                        startIcon={<CreateOutlinedIcon />}
                      >
                        Update Server Deployment
                      </Button>
                    </Tooltip>
                    <Tooltip title="Delete the GPU server instance">
                      <Button
                        variant="outlined"
                        startIcon={<RemoveCircleOutlineOutlinedIcon />}
                        onClick={handleRemoveWorkspaceOpen}
                        sx={{
                          fontSize: '14px',
                          mr: '10px',
                          textTransform: 'none'
                        }}
                        size="small"
                        disabled={checkStatusInProgress || provisioning}
                        color="success"
                      >
                        Remove
                      </Button>
                    </Tooltip>
                    {provisioning && (
                      <Box sx={{ display: 'flex', ml: '5px' }}>
                        <CircularProgress />
                      </Box>
                    )}
                  </>
                )}
              </Box>
            </CardActions>
          </form>
        </Card>
        <Card sx={{ width: '49%' }}>
          <CardHeader
            titleTypographyProps={{ variant: 'subtitle2' }}
            title="Workspace details"
          />
          <CardActions>
            <Box display={'flex'} flexDirection={'row'}>
              <Tooltip title="Click the button to get latest workspace status">
                <Button
                  variant="outlined"
                  startIcon={<RefreshOutlinedIcon />}
                  onClick={handleWorkspaceStatus}
                  sx={{ fontSize: '14px', mr: '10px', textTransform: 'none' }}
                  size="small"
                  color="success"
                  disabled={checkStatusInProgress}
                >
                  Workspace information
                </Button>
              </Tooltip>
              <Tooltip title="Click the button to get latest server details">
                <Button
                  variant="outlined"
                  startIcon={<StorageOutlinedIcon />}
                  onClick={handleServerStatus}
                  sx={{ fontSize: '14px', mr: '10px', textTransform: 'none' }}
                  size="small"
                  color="success"
                  disabled={checkStatusInProgress}
                >
                  Server information
                </Button>
              </Tooltip>
              <Tooltip title="Click the button to get server activity log">
                <Button
                  variant="outlined"
                  startIcon={<StorageOutlinedIcon />}
                  onClick={handleServerActivityLog}
                  sx={{ fontSize: '14px', mr: '10px', textTransform: 'none' }}
                  size="small"
                  color="success"
                  disabled={checkStatusInProgress}
                >
                  Activity log
                </Button>
              </Tooltip>
            </Box>
          </CardActions>

          <CardContent>
            {workspaceStatusResponse.id && (
              <Box>
                <Box display={'flex'} flexDirection={'row'}>
                  <Box mr={'10px'}>
                    <Typography sx={{ fontWeight: 'bold' }}>
                      Workspace Id:
                    </Typography>
                  </Box>
                  <Box mr={'10px'}>
                    <Typography>{workspaceStatusResponse.id}</Typography>
                  </Box>
                </Box>
                <Box display={'flex'} flexDirection={'row'}>
                  <Box mr={'10px'}>
                    <Typography sx={{ fontWeight: 'bold' }}>
                      Workspace Name:
                    </Typography>
                  </Box>
                  <Box mr={'10px'}>
                    <Typography>{workspaceStatusResponse.name}</Typography>
                  </Box>
                </Box>
                <Box display={'flex'} flexDirection={'row'}>
                  <Box mr={'10px'}>
                    <Typography sx={{ fontWeight: 'bold' }}>
                      Workspace Status:
                    </Typography>
                  </Box>
                  <Box mr={'10px'}>
                    <Typography>{workspaceStatusResponse.status}</Typography>
                  </Box>
                </Box>
                <Box display={'flex'} flexDirection={'row'}>
                  <Box mr={'10px'}>
                    <Typography sx={{ fontWeight: 'bold' }}>
                      Workspace Url:
                    </Typography>
                  </Box>
                  <Box mr={'10px'}>
                    <Link
                      href={
                        'https://cloud.ibm.com/schematics/workspaces/' +
                        workspaceStatusResponse.id +
                        '/settings'
                      }
                      underline="hover"
                      target="_blank"
                    >
                      https://cloud.ibm.com/schematics/workspaces/
                      {workspaceStatusResponse.id}/settings
                    </Link>
                  </Box>
                </Box>
                <TableContainer component={Paper}>
                  <Table size="small" aria-label="Variable details">
                    <TableHead>
                      <TableRow>
                        <TableCell>Name</TableCell>
                        <TableCell>Value</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {workspaceStatusResponse.variablestore.map(
                        (row: { name: string; value: string }) => (
                          <TableRow
                            key={row?.name}
                            sx={{
                              '&:last-child td, &:last-child th': { border: 0 }
                            }}
                          >
                            <TableCell>{row.name}</TableCell>
                            <TableCell>{row.value}</TableCell>
                          </TableRow>
                        )
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            )}
            {server_details.id && (
              <Box>
                <Typography variant="h6" mb={'5px'} mt={'10px'}>
                  Server Details
                </Typography>
                <TableContainer component={Paper}>
                  <Table size="small" aria-label="Variable details">
                    <TableBody>
                      <TableRow>
                        <TableCell>Id</TableCell>
                        <TableCell>{server_details.id}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Jupyter server url</TableCell>
                        <TableCell>
                          {
                            server_details.output_values[0].jupyter_server_url
                              .value
                          }
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Server IP</TableCell>
                        <TableCell>
                          {server_details.output_values[0].public_ip.value}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Login command</TableCell>
                        <TableCell>
                          ssh root@
                          {server_details.output_values[0].public_ip.value}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>
            )}
          </CardContent>
        </Card>
      </Box>
      <Dialog
        open={openRemoveWorkspaceAgree}
        onClose={handleRemoveWorkspaceClose}
        aria-labelledby="alert-dialog-remove-workspace-title"
        aria-describedby="alert-dialog-remove-workspace-description"
      >
        <DialogTitle id="alert-dialog-create-workspace-title">
          {'Are you sure want to remove this GPU server?'}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-create-workspace-description">
            This action will delete the workspace and the GPU server. All of the
            resources will be removed and cannot be rolled back.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleRemoveWorkspaceClose}>No</Button>
          <Button onClick={handleDeleteWorkspace} autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={openCreateWorkspaceAgree}
        onClose={handleRemoveWorkspaceClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-create-workspace"
      >
        <DialogContent dividers>
          <TableContainer component={Paper}>
            <Typography variant="subtitle1" gutterBottom component="div">
              Below are the details for provisioning a GPU server.
            </Typography>
            <Table size="small" aria-label="Variable details">
              <TableHead>
                <TableRow>
                  <TableCell>Name</TableCell>
                  <TableCell>Value</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>Ssh Key</TableCell>
                  <TableCell>{formik.values.ssh_key_name}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Region</TableCell>
                  <TableCell>{formik.values.region}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Zone</TableCell>
                  <TableCell>{formik.values.zone}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>GPU Profile</TableCell>
                  <TableCell>{formik.values.vpc_vsi_profile_name}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>OS Profile</TableCell>
                  <TableCell>{formik.values.vpc_vsi_image_name}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Resourse Group</TableCell>
                  <TableCell>{formik.values.resource_group_name}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>Jupyter Lab Image</TableCell>
                  <TableCell>{formik.values.jupyter_lab_image}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
          <DialogContentText
            id="alert-dialog-create-workspace-description"
            variant="subtitle2"
            mt={'10px'}
          >
            There will be a cost associated with this environment. Please review
            and confirm it before submitting the request. Visit the URL{' '}
            <Link
              href="https://www.ibm.com/cloud/cloud-calculator"
              underline="hover"
              target="_blank"
            >
              https://www.ibm.com/cloud/cloud-calculator
            </Link>{' '}
            to review the associated costs.
          </DialogContentText>
        </DialogContent>
        <DialogTitle id="alert-dialog-create-workspace-title">
          {'Are you sure want to create this GPU server in IBM Cloud?'}
        </DialogTitle>
        <DialogActions>
          <Button onClick={handleCreateWorkspaceClose}>No</Button>
          <Button onClick={handleProvisionWorkspace} autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <Modal open={activityLogModal} onClose={() => setActivityLogModal(false)}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 800,
            bgcolor: 'background.paper',
            border: '2px solid #000',
            boxShadow: 24,
            p: 4
          }}
        >
          <Box
            display={'flex'}
            flexDirection={'row'}
            justifyContent={'space-between'}
          >
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Server activity log
            </Typography>
            <IconButton
              aria-label="delete"
              size="large"
              onClick={() => setActivityLogModal(false)}
            >
              <CloseIcon />
            </IconButton>
          </Box>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <pre
              style={{
                textWrap: 'wrap'
              }}
            >
              {activityLogContent !== '' && activityLogContent}
            </pre>
          </Typography>
        </Box>
      </Modal>
    </Box>
  );
};

/**
 * A Counter Lumino Widget that wraps a GPUProvisionComponent.
 */
export class GPUProvisionWidget extends ReactWidget {
  /**
   * Constructs a new GPUProvisionWidget.
   */
  constructor() {
    super();
    this.addClass('jp-react-widget');
  }

  render(): JSX.Element {
    return <GPUProvisionComponent />;
  }
}
