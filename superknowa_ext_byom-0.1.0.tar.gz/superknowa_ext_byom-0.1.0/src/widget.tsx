import { ReactWidget } from '@jupyterlab/ui-components';
import {
  Box,
  Typography,
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  Button,
  MenuItem,
  Select,
  TextField,
  Alert,
  Card,
  CardContent,
  CardActions,
  CardHeader,
  IconButton,
  Tooltip,
  CircularProgress,
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  LinearProgress
} from '@mui/material';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Visibility from '@mui/icons-material/Visibility';
import React from 'react';
import IBMIcon from './IBMIcon';
import { requestAPI } from './handler';
import RefreshOutlinedIcon from '@mui/icons-material/RefreshOutlined';
import RemoveCircleOutlineOutlinedIcon from '@mui/icons-material/RemoveCircleOutlineOutlined';
import StorageOutlinedIcon from '@mui/icons-material/StorageOutlined';
/**
 * React component for a counter.
 *
 * @returns The React component
 */
const GPUProvisionComponent = (): JSX.Element => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [showPat, setShowPat] = React.useState(false);
  const [ibmApiKey, setIbmApiKey] = React.useState('');
  const [githubPAT, setGithubPAT] = React.useState('');
  const [vpc_vsi_profile_name, setVpc_vsi_profile_name] =
    React.useState('gx2-8x64x1v100');
  const [vpc_vsi_image_name, setVpc_vsi_image_name] = React.useState(
    'ibm-ubuntu-22-04-3-minimal-amd64-1'
  );
  const [region, setRegion] = React.useState('eu-gb');
  const [zone, setZone] = React.useState('eu-gb-1');
  const [ssh_key_name, setSsh_key_name] = React.useState('');

  const [server_details, setServer_details] = React.useState('');

  const [provisionInProgress, setProvisionInProgress] = React.useState(false);
  const [checkStatusInProgress, setCheckStatusInProgress] =
    React.useState(false);

  const [submitStatus, setSubmitStatus] = React.useState({
    status: '',
    message: ''
  });

  const handleClickShowPassword = () => setShowPassword(show => !show);
  const handleClickShowGithubPAT = () => setShowPat(show => !show);

  const [openRemoveWorkspaceAgree, setOpenRemoveWorkspaceAgree] =
    React.useState(false);

  const handleRemoveWorkspaceOpen = () => {
    setOpenRemoveWorkspaceAgree(true);
  };

  const handleRemoveWorkspaceClose = () => {
    setOpenRemoveWorkspaceAgree(false);
  };

  const [openCreateWorkspaceAgree, setOpenCreateWorkspaceAgree] =
    React.useState(false);

  const handleCreateWorkspaceOpen = () => {
    setOpenCreateWorkspaceAgree(true);
  };

  const handleCreateWorkspaceClose = () => {
    setOpenCreateWorkspaceAgree(false);
  };

  const region_zone = [
    {
      label: 'Americas',
      region: [
        {
          label: 'Dallas',
          value: 'us-south',
          zone: ['us-south-1', 'us-south-2', 'us-south-3']
        },
        {
          label: 'Sao Paulo',
          value: 'br-sao',
          zone: ['br-sao-1', 'br-sao-2', 'br-sao-3']
        },
        {
          label: 'Toronto',
          value: 'ca-tor',
          zone: ['ca-tor-1', 'ca-tor-2', 'ca-tor-3']
        },
        {
          label: 'Washington DC',
          value: 'us-east',
          zone: ['us-east-1', 'us-east-2', 'us-east-3']
        }
      ]
    },
    {
      label: 'Europe',
      region: [
        {
          label: 'Frankfurt',
          value: 'eu-de',
          zone: ['eu-de-1', 'eu-de-2', 'eu-de-3']
        },
        {
          label: 'London',
          value: 'eu-gb',
          zone: ['eu-gb-1', 'eu-gb-2', 'eu-gb-3']
        },
        {
          label: 'Madrid',
          value: 'eu-es',
          zone: ['eu-es-1', 'eu-es-2', 'eu-es-3']
        }
      ]
    },
    {
      label: 'Asia Pacific',
      region: [
        {
          label: 'Sydney',
          value: 'au-syd',
          zone: ['au-syd-1', 'au-syd-2', 'au-syd-3']
        },
        {
          label: 'Tokyo',
          value: 'jp-tok',
          zone: ['jp-tok-1', 'jp-tok-2', 'jp-tok-3']
        }
      ]
    }
  ];

  const handleProvisionClick = async () => {
    setOpenCreateWorkspaceAgree(false);
    setSubmitStatus({
      status: '',
      message: ''
    });

    if (!ibmApiKey) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid ibm api key'
      });
      return;
    }

    if (!githubPAT) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid github personal access token'
      });
      return;
    }

    if (!zone) {
      setSubmitStatus({
        status: 'error',
        message: 'Please select a valid zone'
      });
      return;
    }

    if (!ssh_key_name) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid ssh key'
      });
      return;
    }

    setProvisionInProgress(true);
    const init: RequestInit = {};
    init.method = 'post';
    init.body = JSON.stringify({
      ibm_iam_token: ibmApiKey,
      githubPAT: githubPAT,
      vpc_vsi_profile_name,
      vpc_vsi_image_name,
      region,
      zone,
      ssh_key_name
    });
    requestAPI<any>('workspace', init)
      .then(data => {
        if (data.type === 'existing') {
          setSubmitStatus({
            status: 'success',
            message: 'A  workspace is already exist'
          });
        } else if (data.type === 'new') {
          setSubmitStatus({
            status: 'success',
            message:
              'Successfully submitted request, it will take some time to complete the request. Please hit the refresh button to get the latest status'
          });
        }

        setWorkspaceStatusResponse({
          id: data.data.id,
          name: data.data.name,
          status: data.data.status,
          variablestore: data.data.template_data[0].variablestore
        });
        setProvisionInProgress(false);
      })
      .catch(reason => {
        setSubmitStatus({
          status: 'error',
          message: `The superknowa_ext_byom server extension appears to be missing.\n${reason}`
        });
        console.error(
          `Error in creating new workspace. Please contact administrator to resolve the issue.\n${reason}`
        );
        setProvisionInProgress(false);
      });
  };

  const [workspaceStatusResponse, setWorkspaceStatusResponse] = React.useState({
    id: '',
    name: '',
    status: '',
    variablestore: [
      {
        name: '',
        value: ''
      }
    ]
  });

  const handleWorkspaceStatus = async () => {
    const init: RequestInit = {};
    init.method = 'post';
    setSubmitStatus({
      status: '',
      message: ''
    });
    if (!ibmApiKey) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid ibm api key'
      });
      return;
    }
    setCheckStatusInProgress(true);
    init.body = JSON.stringify({
      ibm_iam_token: ibmApiKey
    });
    requestAPI<any>('wstatus', init)
      .then(data => {
        if (data.status === 'success') {
          setWorkspaceStatusResponse({
            id: data.data.id,
            name: data.data.name,
            status: data.data.status,
            variablestore: data.data.template_data[0].variablestore
          });
        } else {
          setSubmitStatus({
            status: 'error',
            message: data.message
          });
          setWorkspaceStatusResponse({
            id: 'Not found',
            name: 'Not found',
            status: 'Unknown',
            variablestore: []
          });
        }
        setCheckStatusInProgress(false);
      })
      .catch(reason => {
        const response = {
          id: 'Not found',
          name: 'Not found',
          status: 'Unknown',
          variablestore: []
        };
        setWorkspaceStatusResponse(response);
        console.error(
          'Error in getting workspace status. Workspace may not exist.'
        );
        setCheckStatusInProgress(false);
      });
  };

  const handleServerStatus = async () => {
    const init: RequestInit = {};
    init.method = 'post';
    setSubmitStatus({
      status: '',
      message: ''
    });
    if (!ibmApiKey) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid ibm api key'
      });
      return;
    }
    setCheckStatusInProgress(true);
    init.body = JSON.stringify({
      ibm_iam_token: ibmApiKey
    });

    requestAPI<any>('serverstatus', init)
      .then(data => {
        if (data.status === 'success') {
          setServer_details(JSON.stringify(data));
        } else {
          setSubmitStatus({
            status: 'error',
            message: data.message
          });
        }
        setCheckStatusInProgress(false);
      })
      .catch(reason => {
        console.error(reason);
        setSubmitStatus({
          status: 'error',
          message: 'Error in getting server details. Server might not exist'
        });
        setCheckStatusInProgress(false);
      });
  };

  const handleDeleteWorkspace = async () => {
    setOpenRemoveWorkspaceAgree(false);
    const init: RequestInit = {};
    init.method = 'post';

    setSubmitStatus({
      status: '',
      message: ''
    });
    if (!ibmApiKey) {
      setSubmitStatus({
        status: 'error',
        message: 'Please enter a valid ibm api key'
      });
      return;
    }
    setCheckStatusInProgress(true);
    init.body = JSON.stringify({
      ibm_iam_token: ibmApiKey
    });
    requestAPI<any>('wdelete', init)
      .then(data => {
        if (data.status === 'success') {
          setSubmitStatus({
            status: 'success',
            message:
              'Workspace is being deleted. Click on the check status button to get latest status'
          });
          //setWorkspaceStatusResponse(response);
        } else {
          setSubmitStatus({
            status: 'error',
            message: data.message
          });
        }
        setCheckStatusInProgress(false);
      })
      .catch(reason => {
        const response = {
          id: 'Deleting..',
          name: 'Deleting..',
          status: 'Deletion in progress',
          variablestore: []
        };
        setWorkspaceStatusResponse(response);
        console.error(`Error in deleting workspace status.\n${reason}`);
        setCheckStatusInProgress(false);
      });
  };

  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  const handleMouseDownShowPat = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    event.preventDefault();
  };

  return (
    <Box>
      <Box display={'flex'} justifyContent={'center'}>
        <Typography>
          <IBMIcon />
        </Typography>
        <Typography
          mt={'12px'}
          variant="h5"
          height={'30px'}
          noWrap
          sx={{
            display: { xs: 'none', md: 'flex' },
            fontWeight: 500,
            textDecoration: 'none'
          }}
        >
          Ecosystem Engineering
        </Typography>
      </Box>
      <Box display={'flex'} justifyContent={'center'}>
        <Typography
          mt={'5px'}
          height={'30px'}
          noWrap
          sx={{
            display: { xs: 'none', md: 'flex' },
            fontWeight: 500,
            textDecoration: 'none'
          }}
        >
          Superknowa BYOM
        </Typography>
      </Box>

      <Box
        display={'flex'}
        mt={'50px'}
        flexDirection={'row'}
        alignContent={'center'}
        justifyContent={'center'}
      >
        {submitStatus.status === 'success' && (
          <Alert
            sx={{ marginBottom: '20px' }}
            variant="outlined"
            severity="success"
          >
            {submitStatus.message}
          </Alert>
        )}
        {submitStatus.status === 'error' && (
          <Alert
            sx={{ marginBottom: '20px' }}
            variant="outlined"
            severity="error"
          >
            {submitStatus.message}
          </Alert>
        )}
      </Box>
      {checkStatusInProgress && (
        <Box
          display={'flex'}
          flexDirection={'row'}
          alignContent={'center'}
          justifyContent={'center'}
          ml={'50px'}
          mr={'50px'}
        >
          <LinearProgress sx={{ width: '100%' }} color="success" />
        </Box>
      )}
      <Box
        display={'flex'}
        ml={'50px'}
        mr={'50px'}
        flexDirection={'row'}
        justifyContent={'space-between'}
      >
        <Card sx={{ width: '49%' }}>
          <CardHeader
            titleTypographyProps={{ variant: 'subtitle1' }}
            title="Provision a GPU server for training, inference, and deploying an LLM model."
          />
          <CardContent>
            <Box display={'flex'} margin={'5px'} flexDirection={'column'}>
              <FormControl sx={{ width: '60ch' }} variant="outlined">
                <InputLabel
                  htmlFor="outlined-adornment-password"
                  sx={{ fontSize: '14px' }}
                >
                  Api key
                </InputLabel>
                <OutlinedInput
                  margin="dense"
                  sx={{ height: '40px' }}
                  id="outlined-adornment-password"
                  type={showPassword ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                  label="Api Key"
                  onChange={e => {
                    e.preventDefault();
                    setIbmApiKey(e.target.value);
                  }}
                />
              </FormControl>
              <FormControl
                sx={{ width: '60ch', mt: '10px' }}
                variant="outlined"
              >
                <InputLabel
                  htmlFor="outlined-adornment-github"
                  sx={{ fontSize: '14px' }}
                >
                  Github access token
                </InputLabel>
                <OutlinedInput
                  margin="dense"
                  sx={{ height: '40px' }}
                  id="outlined-adornment-github"
                  type={showPat ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowGithubPAT}
                        onMouseDown={handleMouseDownShowPat}
                        edge="end"
                      >
                        {showPat ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                  label="Github access token"
                  onChange={e => {
                    e.preventDefault();
                    setGithubPAT(e.target.value);
                  }}
                />
              </FormControl>
              <Box display={'flex'} flexDirection={'row'} marginTop={'15px'}>
                <FormControl sx={{ minWidth: 120 }}>
                  <InputLabel
                    htmlFor="region-group-select"
                    sx={{ fontSize: '14px' }}
                  >
                    Region
                  </InputLabel>
                  <Select
                    sx={{ height: '40px', fontSize: '14px' }}
                    native
                    defaultValue=""
                    id="region-group-select"
                    label="Region"
                    value={region}
                    onChange={e => {
                      e.preventDefault();
                      setRegion(e.target.value);
                      setZone('');
                    }}
                  >
                    <option aria-label="None" value="" />
                    {region_zone.map((reg, _inx) => {
                      return (
                        <optgroup key={_inx} label={reg.label}>
                          {reg.region.map((reg_name, _rinx) => {
                            return (
                              <option key={_rinx} value={reg_name.value}>
                                {reg_name.label}
                              </option>
                            );
                          })}
                        </optgroup>
                      );
                    })}
                  </Select>
                </FormControl>
                <FormControl
                  sx={{ width: '150px', marginLeft: '10px' }}
                  variant="outlined"
                >
                  <InputLabel id="zone-select-label" sx={{ fontSize: '14px' }}>
                    Zone
                  </InputLabel>
                  <Select
                    sx={{ height: '40px', fontSize: '14px' }}
                    labelId="zone-select-label"
                    id="zone-simple-select"
                    value={zone}
                    label="Zone"
                    onChange={e => {
                      setZone(e.target.value);
                    }}
                  >
                    {region_zone
                      .flatMap(reg => reg.region)
                      .filter(zn => zn.value === region)
                      .flatMap(item => item.zone)
                      .map((fzone, _inx) => {
                        return (
                          <MenuItem key={_inx} value={fzone}>
                            {fzone}
                          </MenuItem>
                        );
                      })}
                  </Select>
                </FormControl>
              </Box>
              <FormControl
                sx={{ width: '50ch', marginTop: '15px' }}
                variant="outlined"
              >
                <InputLabel
                  id="image-vsi-select-label"
                  sx={{ fontSize: '14px' }}
                >
                  VPC VSI Image Name
                </InputLabel>
                <Select
                  sx={{ height: '40px', fontSize: '14px' }}
                  labelId="image-vsi-select-label"
                  id="demo-simple-select"
                  value={vpc_vsi_image_name}
                  label="VPC GPU Profile"
                  onChange={e => {
                    setVpc_vsi_image_name(e.target.value);
                  }}
                >
                  <MenuItem value={'ibm-ubuntu-22-04-3-minimal-amd64-1'}>
                    ibm-ubuntu-22-04-3-minimal-amd64-1
                  </MenuItem>
                  <MenuItem value={'ibm-ubuntu-22-04-3-minimal-amd64-2'}>
                    ibm-ubuntu-22-04-3-minimal-amd64-2
                  </MenuItem>
                  <MenuItem value={'ibm-ubuntu-20-04-6-minimal-amd64-3'}>
                    ibm-ubuntu-20-04-6-minimal-amd64-3
                  </MenuItem>
                </Select>
              </FormControl>
              <FormControl
                sx={{ width: '50ch', marginTop: '15px' }}
                variant="outlined"
              >
                <InputLabel
                  id="demo-simple-select-label"
                  sx={{ fontSize: '14px' }}
                >
                  VPC GPU Profile
                </InputLabel>
                <Select
                  sx={{ height: '40px', fontSize: '14px' }}
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={vpc_vsi_profile_name}
                  label="VPC GPU Profile"
                  onChange={e => {
                    setVpc_vsi_profile_name(e.target.value);
                  }}
                >
                  <MenuItem value={'gx2-8x64x1v100'}>gx2-8x64x1v100</MenuItem>
                  <MenuItem value={'gx2-16x128x1v100'}>
                    gx2-16x128x1v100
                  </MenuItem>
                  <MenuItem value={'gx2-16x128x2v100'}>
                    gx2-16x128x2v100
                  </MenuItem>
                  <MenuItem value={'gx2-32x256x2v100'}>
                    gx2-32x256x2v100
                  </MenuItem>
                </Select>
              </FormControl>
              <TextField
                margin="dense"
                sx={{
                  width: '40ch',
                  marginTop: '15px'
                }}
                id="outlined-multiline-flexible"
                label="ssh key name"
                value={ssh_key_name}
                onChange={e => setSsh_key_name(e.target.value)}
                inputProps={{
                  style: {
                    height: 10
                  }
                }}
              />
              <Box>
                <Typography
                  fontSize={'12px'}
                  color={'red'}
                  fontStyle={'italic'}
                >
                  Please make sure you write correct ssh key based on the region
                  you selected above, otherwise you will not be able to access
                  the VM after it provisioned.
                </Typography>
              </Box>
            </Box>
          </CardContent>
          <CardActions>
            <Box marginTop={'15px'} display={'flex'} flexDirection={'row'}>
              <Button
                disabled={provisionInProgress}
                variant="outlined"
                size="small"
                onClick={handleCreateWorkspaceOpen}
                sx={{ fontSize: '14px', mr: '10px' }}
              >
                Provision
              </Button>
              {provisionInProgress && <CircularProgress />}
            </Box>
          </CardActions>
        </Card>
        <Card sx={{ width: '49%' }}>
          <CardHeader
            titleTypographyProps={{ variant: 'subtitle1' }}
            title="Workspace details"
          />
          <CardActions>
            <Box display={'flex'} flexDirection={'row'}>
              <Tooltip title="Click the button to get latest workspace status">
                <Button
                  variant="outlined"
                  startIcon={<RefreshOutlinedIcon />}
                  onClick={handleWorkspaceStatus}
                  sx={{ mr: '20px' }}
                  size="small"
                >
                  Check workspace status
                </Button>
              </Tooltip>
              <Tooltip title="Click the button to get latest server details">
                <Button
                  variant="outlined"
                  startIcon={<StorageOutlinedIcon />}
                  onClick={handleServerStatus}
                  sx={{ mr: '20px' }}
                  size="small"
                >
                  Check server status
                </Button>
              </Tooltip>
              <Tooltip title="Delete the GPU server instance">
                <Button
                  variant="outlined"
                  startIcon={<RemoveCircleOutlineOutlinedIcon />}
                  onClick={handleRemoveWorkspaceOpen}
                  size="small"
                >
                  Remove
                </Button>
              </Tooltip>
            </Box>
          </CardActions>
          {workspaceStatusResponse.id && (
            <CardContent>
              <Box display={'flex'} flexDirection={'row'}>
                <Box mr={'10px'}>
                  <Typography sx={{ fontWeight: 'bold' }}>
                    Workspace Id:
                  </Typography>
                </Box>
                <Box mr={'10px'}>
                  <Typography>{workspaceStatusResponse.id}</Typography>
                </Box>
              </Box>
              <Box display={'flex'} flexDirection={'row'}>
                <Box mr={'10px'}>
                  <Typography sx={{ fontWeight: 'bold' }}>
                    Workspace Name:
                  </Typography>
                </Box>
                <Box mr={'10px'}>
                  <Typography>{workspaceStatusResponse.name}</Typography>
                </Box>
              </Box>
              <Box display={'flex'} flexDirection={'row'}>
                <Box mr={'10px'}>
                  <Typography sx={{ fontWeight: 'bold' }}>
                    Workspace Status:
                  </Typography>
                </Box>
                <Box mr={'10px'}>
                  <Typography>{workspaceStatusResponse.status}</Typography>
                </Box>
              </Box>
              <TableContainer component={Paper}>
                <Table size="small" aria-label="Variable details">
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Value</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {workspaceStatusResponse.variablestore.map(row => (
                      <TableRow
                        key={row.name}
                        sx={{
                          '&:last-child td, &:last-child th': { border: 0 }
                        }}
                      >
                        <TableCell>{row.name}</TableCell>
                        <TableCell>{row.value}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <Box>
                <Typography variant="h6" mb={'5px'} mt={'10px'}>
                  Server Details
                </Typography>
                <Box
                  border={'1px dashed black'}
                  borderRadius={'8px'}
                  padding={'5px'}
                >
                  {server_details}
                </Box>
              </Box>
            </CardContent>
          )}
        </Card>
      </Box>
      <Dialog
        open={openRemoveWorkspaceAgree}
        onClose={handleRemoveWorkspaceClose}
        aria-labelledby="alert-dialog-remove-workspace-title"
        aria-describedby="alert-dialog-remove-workspace-description"
      >
        <DialogTitle id="alert-dialog-create-workspace-title">
          {'Are you sure want to remove this GPU server?'}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-create-workspace-description">
            This action will delete the workspace and the GPU server. All of the
            resources will be removed and cannot be rolled back.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleRemoveWorkspaceClose}>No</Button>
          <Button onClick={handleDeleteWorkspace} autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={openCreateWorkspaceAgree}
        onClose={handleRemoveWorkspaceClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-create-workspace"
      >
        <DialogTitle id="alert-dialog-create-workspace-title">
          {'Are you sure want to create this GPU server?'}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-create-workspace-description">
            There will be a cost associated with this enviroment. Please review
            IBM cloud docs for more information.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCreateWorkspaceClose}>No</Button>
          <Button onClick={handleProvisionClick} autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

/**
 * A Counter Lumino Widget that wraps a GPUProvisionComponent.
 */
export class GPUProvisionWidget extends ReactWidget {
  /**
   * Constructs a new GPUProvisionWidget.
   */
  constructor() {
    super();
    this.addClass('jp-react-widget');
  }

  render(): JSX.Element {
    return <GPUProvisionComponent />;
  }
}
