import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import { ILauncher } from '@jupyterlab/launcher';

import { requestAPI } from './handler';
import { GPUProvisionWidget } from './widget';
import { MainAreaWidget } from '@jupyterlab/apputils';
import { listIcon } from '@jupyterlab/ui-components';

/**
 * The command IDs used by the react-widget plugin.
 */
namespace CommandIDs {
  export const create = 'create-superknowa-widget';
}

/**
 * Initialization data for the superknowa-ext-byom extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'superknowa-ext-byom:plugin',
  description:
    'Superknowa BYOM Jupyterlab extension to provsion a development environment',
  autoStart: true,
  optional: [ILauncher],
  activate: (app: JupyterFrontEnd, launcher: ILauncher) => {
    console.log('JupyterLab extension superknowa-ext-byom is being activated!');

    const { commands } = app;

    const command = CommandIDs.create;
    commands.addCommand(command, {
      caption: 'Bring your own model superknowa byom',
      label: 'Superknowa BYOM',
      icon: args => (args['isPalette'] ? undefined : listIcon),
      execute: () => {
        const content = new GPUProvisionWidget();
        const widget = new MainAreaWidget<GPUProvisionWidget>({ content });
        widget.title.label = 'Superknowa BYOM';
        widget.title.icon = listIcon;
        app.shell.add(widget, 'main');
      }
    });

    requestAPI<any>('test')
      .then(data => {
        console.log(data);
      })
      .catch(reason => {
        console.error(
          `The superknowa_ext_byom server extension appears to be missing.\n${reason}`
        );
      });

    if (launcher) {
      launcher.add({
        command
      });
    }
    console.log('JupyterLab extension superknowa-ext-byom is activated!');
  }
};

export default plugin;
