import { SetStateAction } from 'react';
import { requestAPI } from '../handler';

export const region_zone = [
  {
    label: 'Americas',
    region: [
      {
        label: 'Dallas',
        value: 'us-south',
        zone: ['us-south-1', 'us-south-2', 'us-south-3']
      },
      {
        label: 'Sao Paulo',
        value: 'br-sao',
        zone: ['br-sao-1', 'br-sao-2', 'br-sao-3']
      },
      {
        label: 'Toronto',
        value: 'ca-tor',
        zone: ['ca-tor-1', 'ca-tor-2', 'ca-tor-3']
      },
      {
        label: 'Washington DC',
        value: 'us-east',
        zone: ['us-east-1', 'us-east-2', 'us-east-3']
      }
    ]
  },
  {
    label: 'Europe',
    region: [
      {
        label: 'Frankfurt',
        value: 'eu-de',
        zone: ['eu-de-1', 'eu-de-2', 'eu-de-3']
      },
      {
        label: 'London',
        value: 'eu-gb',
        zone: ['eu-gb-1', 'eu-gb-2', 'eu-gb-3']
      },
      {
        label: 'Madrid',
        value: 'eu-es',
        zone: ['eu-es-1', 'eu-es-2', 'eu-es-3']
      }
    ]
  },
  {
    label: 'Asia Pacific',
    region: [
      {
        label: 'Sydney',
        value: 'au-syd',
        zone: ['au-syd-1', 'au-syd-2', 'au-syd-3']
      },
      {
        label: 'Tokyo',
        value: 'jp-tok',
        zone: ['jp-tok-1', 'jp-tok-2', 'jp-tok-3']
      }
    ]
  }
];

export const gpu_profiles = [
  {
    label: 'gx2 v100',
    profiles: [
      {
        key: 'gx2-8x64x1v100',
        value: 'gx2-8x64x1v100'
      },
      {
        key: 'gx2-16x128x1v100',
        value: 'gx2-16x128x1v100'
      },
      {
        key: 'gx2-16x128x2v100',
        value: 'gx2-16x128x2v100'
      },
      {
        key: 'gx2-32x256x2v100',
        value: 'gx2-32x256x2v100'
      }
    ]
  },
  {
    label: 'gx2 a100',
    profiles: [
      {
        key: 'gx2-8x64x1v100',
        value: 'gx2-8x64x1v100'
      },
      {
        key: 'gx2-16x128x1v100',
        value: 'gx2-16x128x1v100'
      },
      {
        key: 'gx2-16x128x2v100',
        value: 'gx2-16x128x2v100'
      },
      {
        key: 'gx2-32x256x2v100',
        value: 'gx2-32x256x2v100'
      }
    ]
  },
  {
    label: 'gx3 l4',
    profiles: [
      {
        key: 'gx3-16x80x1l4',
        value: 'gx3-16x80x1l4'
      },
      {
        key: 'gx3-32x160x2l4',
        value: 'gx3-32x160x2l4'
      },
      {
        key: 'gx3-64x320x4l4',
        value: 'gx3-64x320x4l4'
      }
    ]
  }
];

export const checkWorkspaceStatus = async (
  ibmApiKey: any,
  setCheckStatusInProgress: (arg0: boolean) => void,
  setSubmitStatus: {
    (value: SetStateAction<{ status: string; message: string }>): void;
    (arg0: { status: string; message: string }): void;
  },
  setWorkspaceStatusResponse: {
    (
      value: SetStateAction<{
        id: string;
        name: string;
        status: string;
        variablestore: { name: string; value: string }[];
      }>
    ): void;
    (arg0: { id: any; name: any; status: any; variablestore: any }): void;
  },
  setServer_details: (arg0: {
    id: string;
    folder: string;
    type: string;
    output_values: {
      jupyter_server_url: { type: string; value: string };
      public_ip: { type: string; value: string };
    }[];
  }) => void
) => {
  const init: RequestInit = {};
  init.method = 'post';
  if (!ibmApiKey) {
    setSubmitStatus({
      status: 'error',
      message: 'Please enter a valid ibm api key'
    });
    setWorkspaceStatusResponse({
      id: '',
      name: '',
      status: '',
      variablestore: []
    });
    setCheckStatusInProgress(false);
    return;
  }
  init.body = JSON.stringify({
    ibm_iam_token: ibmApiKey
  });

  requestAPI<any>('wstatus', init)
    .then(data => {
      if (data.status === 'success') {
        setSubmitStatus({
          status: '',
          message: ''
        });

       // console.log(data.data, 'data.data');
        const workspace_state = {
          id: data.data.id,
          name: data.data.name,
          status: data.data.status,
          variablestore: data.data.template_data[0].variablestore
        };
        setWorkspaceStatusResponse(workspace_state);
        store_workspace_state(workspace_state);
      } else {
        setSubmitStatus({
          status: 'error',
          message: data.message
        });

        setWorkspaceStatusResponse({
          id: '',
          name: '',
          status: '',
          variablestore: []
        });

        try {
          setCheckStatusInProgress(false);
          window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
          window.localStorage.removeItem(superknowa_server_inforamtion_key);
        } catch (error) {
          console.error('Erro in deleting cache!!!!');
        }
      }
      setCheckStatusInProgress(false);
    })
    .catch(reason => {
      setSubmitStatus({
        status: 'error',
        message: reason.toString()
      });

      setWorkspaceStatusResponse({
        id: '',
        name: '',
        status: '',
        variablestore: []
      });
      setCheckStatusInProgress(false);
      try {
        window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
        window.localStorage.removeItem(superknowa_server_inforamtion_key);
        setServerStatusError(setServer_details);
      } catch (error) {
        console.error('Erro in deleting cache!!!!');
      }
    });
};

const setServerStatusError = (
  setServer_details: (arg0: {
    id: string;
    folder: string;
    type: string;
    output_values: {
      jupyter_server_url: { type: string; value: string };
      public_ip: { type: string; value: string };
    }[];
  }) => void
) => {
  setServer_details({
    id: '',
    folder: 'terraform',
    type: 'terraform_v1.5',
    output_values: [
      {
        jupyter_server_url: {
          type: 'string',
          value: ''
        },
        public_ip: { type: 'string', value: '' }
      }
    ]
  });
};

export const checkServerStatus = async (
  ibmApiKey: any,
  setCheckStatusInProgress: (arg0: boolean) => void,
  setSubmitStatus: {
    (value: SetStateAction<{ status: string; message: string }>): void;
    (arg0: { status: string; message: string }): void;
  },
  setServer_details: (arg0: {
    id: string;
    folder: string;
    type: string;
    output_values: {
      jupyter_server_url: { type: string; value: string };
      public_ip: { type: string; value: string };
    }[];
  }) => void
) => {
  const init: RequestInit = {};
  init.method = 'post';
  if (!ibmApiKey) {
    setSubmitStatus({
      status: 'error',
      message: 'Please enter a valid ibm api key'
    });
    setServerStatusError(setServer_details);
    setCheckStatusInProgress(false);
    return;
  }

  init.body = JSON.stringify({
    ibm_iam_token: ibmApiKey
  });

  requestAPI<any>('serverstatus', init)
    .then(data => {
      if (data.status === 'success') {
        setSubmitStatus({
          status: '',
          message: ''
        });
        setServer_details(data.data[0]);
        store_server_state(data.data[0]);
      } else {
        setSubmitStatus({
          status: 'error',
          message: data.message
        });
      }

      setCheckStatusInProgress(false);
    })
    .catch(reason => {
      setCheckStatusInProgress(false);
      setSubmitStatus({
        status: 'error',
        message: reason.toString()
      });
    });
};

export const checkServerActivity = async (
  ibmApiKey: any,
  setCheckStatusInProgress: (arg0: boolean) => void,
  setSubmitStatus: {
    (value: SetStateAction<{ status: string; message: string }>): void;
    (arg0: { status: string; message: string }): void;
  },
  setActivityLogContent: {
    (value: SetStateAction<string>): void;
    (arg0: string): void;
  },
  setActivityLogModal: {
    (value: SetStateAction<boolean>): void;
    (arg0: boolean): void;
  }
) => {
  const init: RequestInit = {};
  init.method = 'post';
  if (!ibmApiKey) {
    setSubmitStatus({
      status: 'error',
      message: 'Please enter a valid ibm api key'
    });
    setCheckStatusInProgress(false);
    return;
  }

  init.body = JSON.stringify({
    ibm_iam_token: ibmApiKey
  });

  requestAPI<any>('wactivity', init)
    .then(data => {
      if (data.status === 'success') {
        setSubmitStatus({
          status: '',
          message: ''
        });
        // console.log('data = >', data.data);
        const activity = data.data.actions.map(
          (item: {
            action_id: any;
            name: any;
            status: any;
            performed_at: any;
            performed_by: any;
            templates: {
              message: any;
              log_url: any;
            }[];
          }) => {
            return {
              action_id: item.action_id,
              action_name: item.name,
              status: item.status,
              performed_at: item.performed_at,
              performed_by: item.performed_by,
              log_url: item.templates[0].log_url,
              message: item.templates[0].message
            };
          }
        );
        setActivityLogContent(JSON.stringify(activity, null, 3));
        setActivityLogModal(true);
      } else {
        setSubmitStatus({
          status: 'error',
          message: data.message
        });
      }

      setCheckStatusInProgress(false);
    })
    .catch(reason => {
      setCheckStatusInProgress(false);
      setSubmitStatus({
        status: 'error',
        message: reason.toString()
      });
    });
};

export const requestDeleteWorkspace = async (
  ibmApiKey: any,
  setCheckStatusInProgress: (arg0: boolean) => void,
  setSubmitStatus: {
    (value: SetStateAction<{ status: string; message: string }>): void;
    (arg0: { status: string; message: string }): void;
  }
) => {
  const init: RequestInit = {};
  init.method = 'post';

  if (!ibmApiKey) {
    setSubmitStatus({
      status: 'error',
      message: 'Please enter a valid ibm api key'
    });
    setCheckStatusInProgress(false);
    return;
  }
  init.body = JSON.stringify({
    ibm_iam_token: ibmApiKey
  });

  requestAPI<any>('wdelete', init)
    .then(data => {
      setSubmitStatus({
        status: data.status,
        message:
          data.status === 'success'
            ? 'Workspace is being deleted. It will take some time to complete the request, please hit the workspace information button or enable auto-refresh to get the latest status'
            : data.message
      });
    })
    .catch(reason => {
      setSubmitStatus({
        status: 'error',
        message: reason.toString()
      });
    })
    .finally(() => {
      try {
        setCheckStatusInProgress(false);
        window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
        window.localStorage.removeItem(superknowa_server_inforamtion_key);
      } catch (error) {
        console.error('Erro in deleting cache!!!!');
      }
    });
};

/***
 * This will create workspace and provision a gpu server with user provided input
 */

export const provisionWorkspace = async (
  values: {
    ssh_key_name: any;
    ibm_iam_token: any;
    githubPAT: any;
    vpc_vsi_image_name: any;
    vpc_vsi_profile_name: any;
    resource_group_name: any;
    zone: any;
    region: any;
  },
  setCheckStatusInProgress: (arg0: boolean) => void,
  setSubmitStatus: {
    (value: SetStateAction<{ status: string; message: string }>): void;
    (arg0: { status: string; message: string }): void;
  },
  setWorkspaceStatusResponse: {
    (
      value: SetStateAction<{
        id: string;
        name: string;
        status: string;
        variablestore: { name: string; value: string }[];
      }>
    ): void;
    (arg0: { id: any; name: any; status: any; variablestore: any }): void;
  },
  setProvisioning: {
    (value: SetStateAction<boolean>): void;
    (arg0: boolean): void;
  }
) => {
  const init: RequestInit = {};
  init.method = 'post';
  init.body = JSON.stringify(values);

  const existing_workspace = get_workspace_state();
  let endpoint_api = 'workspace'; // create workspace
  if (existing_workspace.id) {
    endpoint_api = 'wupdate'; // update workspace
  }

  requestAPI<any>(endpoint_api, init)
    .then(data => {
      setCheckStatusInProgress(false);
      setSubmitStatus({
        status: 'success',
        message:
          'The request has been successfully submitted. It may take some time to process. Please wait patiently for the request to complete.'
      });
      const server_response = {
        id: data.data.id,
        name: data.data.name,
        status: data.data.status,
        variablestore: data.data.template_data[0].variablestore
      };
      setWorkspaceStatusResponse(server_response);
      store_workspace_state(server_response);
      setProvisioning(true);
    })
    .catch(reason => {
      setCheckStatusInProgress(false);
      setSubmitStatus({
        status: 'error',
        message: reason.toString()
      });
      if (endpoint_api !== 'wupdate') {
        // if newly created workspace and gives exception then set the error status
        setWorkspaceStatusResponse({
          id: '',
          name: '',
          status: 'error',
          variablestore: []
        });
      }
      // `The superknowa_ext_byom server extension appears to be missing.\n${reason}`
    });
};

const superknowa_workspace_inforamtion_key = 'superknowa_workspace_inforamtion';
const superknowa_server_inforamtion_key = 'superknowa_server_inforamtion_key';

export const store_workspace_state = (data: any) => {
  window.localStorage.setItem(
    superknowa_workspace_inforamtion_key,
    JSON.stringify(data)
  );
};

export const get_workspace_state = () => {
  const newObject = window.localStorage.getItem(
    superknowa_workspace_inforamtion_key
  );

  if (newObject) {
    return JSON.parse(newObject);
  } else {
    return {
      id: '',
      name: '',
      status: '',
      variablestore: [
        {
          name: '',
          value: ''
        }
      ]
    };
  }
};

export const store_server_state = (data: any) => {
  window.localStorage.setItem(
    superknowa_server_inforamtion_key,
    JSON.stringify(data)
  );
};

export const get_server_state = () => {
  const newObject = window.localStorage.getItem(
    superknowa_server_inforamtion_key
  );

  if (newObject) {
    return JSON.parse(newObject);
  } else {
    return {
      id: '',
      folder: 'terraform',
      type: 'terraform_v1.5',
      output_values: [
        {
          jupyter_server_url: {
            type: 'string',
            value: ''
          },
          public_ip: { type: 'string', value: '' }
        }
      ]
    };
  }
};

export const parse_workspace_name = (workspace_name: string) => {
  if (!workspace_name) {
    return '';
  }

  const match = workspace_name.match(/superknowa-byom-(.*?)-workspace/);
  if (match && match.length > 1) {
    const extractedString = match[1];
    return extractedString;
  } else {
    return '';
  }
};
