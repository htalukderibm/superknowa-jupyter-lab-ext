"use strict";
(self["webpackChunksuperknowa_ext_byom"] = self["webpackChunksuperknowa_ext_byom"] || []).push([["lib_index_js"],{

/***/ "./lib/IBMIcon.js":
/*!************************!*\
  !*** ./lib/IBMIcon.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ IBMIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/SvgIcon */ "./node_modules/@mui/material/SvgIcon/SvgIcon.js");


function IBMIcon() {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_1__["default"], { style: { height: '40px', width: '70px' } },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M0 9.6v.876h6.23V9.6zm7.11 0v.876h8.876c0 0-.907-.876-2.107-.876zm10.618 0v.876h5.37l-.32-.876zm9.22 0l-.32.876h5.32V9.6zM0 11.303v.876h6.23v-.876zm7.11.001v.875h9.906c0 0-.116-.674-.317-.875zm10.618 0v.875h5.96l-.295-.875zm8.583 0l-.295.875h5.935v-.875zM1.8 13.006v.877h2.697v-.877zm7.11 0v.877H11.6v-.877zm5.32 0v.877h2.698c0 0 .17-.463.17-.877zm5.296 0v.877H24.3l-.32-.877zm6.205 0l-.32.877H30.2v-.877zM1.8 14.71v.876h2.697v-.876zm7.11 0v.876h6.9c0 0 .576-.45.76-.876zm10.618 0v.876h2.697V15.1l.17.487h4.94l.184-.487v.487H30.2v-.876h-5.064l-.27.742-.27-.742zM1.8 16.414v.876h2.697v-.876zm7.11 0v.876h7.65c-.184-.425-.76-.876-.76-.876zm10.618 0v.876h2.697v-.876zm3.188 0l.326.876h3.705l.3-.876zm4.806 0v.876H30.2v-.876zM1.8 18.117v.876h2.697v-.876zm7.11 0v.876H11.6v-.876zm5.32 0v.876h2.87c0-.413-.17-.876-.17-.876zm5.296 0v.876h2.697v-.876zm3.8 0l.316.876h2.484l.32-.876zm4.194 0v.876H30.2v-.876zM.05 19.82v.877h6.23v-.877zm7.063 0v.877h9.59c.202-.2.317-.877.317-.877zm10.666 0v.877h4.44v-.877zm6.155 0l.325.877h1.264l.305-.877zm3.58 0v.877H32v-.877zM.05 21.524v.876h6.23v-.876zm7.063 0v.875h6.77c1.2 0 2.108-.875 2.108-.875zm10.666 0v.876h4.44v-.876zm6.77 0l.313.873.054.001.318-.875zm2.964 0v.876H32v-.876z" })));
}


/***/ }),

/***/ "./lib/api/schematic.js":
/*!******************************!*\
  !*** ./lib/api/schematic.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkServerActivity: () => (/* binding */ checkServerActivity),
/* harmony export */   checkServerStatus: () => (/* binding */ checkServerStatus),
/* harmony export */   checkWorkspaceStatus: () => (/* binding */ checkWorkspaceStatus),
/* harmony export */   get_server_state: () => (/* binding */ get_server_state),
/* harmony export */   get_workspace_state: () => (/* binding */ get_workspace_state),
/* harmony export */   gpu_profiles: () => (/* binding */ gpu_profiles),
/* harmony export */   parse_workspace_name: () => (/* binding */ parse_workspace_name),
/* harmony export */   provisionWorkspace: () => (/* binding */ provisionWorkspace),
/* harmony export */   region_zone: () => (/* binding */ region_zone),
/* harmony export */   requestDeleteWorkspace: () => (/* binding */ requestDeleteWorkspace),
/* harmony export */   store_server_state: () => (/* binding */ store_server_state),
/* harmony export */   store_workspace_state: () => (/* binding */ store_workspace_state)
/* harmony export */ });
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");

const region_zone = [
    {
        label: 'Americas',
        region: [
            {
                label: 'Dallas',
                value: 'us-south',
                zone: ['us-south-1', 'us-south-2', 'us-south-3']
            },
            {
                label: 'Sao Paulo',
                value: 'br-sao',
                zone: ['br-sao-1', 'br-sao-2', 'br-sao-3']
            },
            {
                label: 'Toronto',
                value: 'ca-tor',
                zone: ['ca-tor-1', 'ca-tor-2', 'ca-tor-3']
            },
            {
                label: 'Washington DC',
                value: 'us-east',
                zone: ['us-east-1', 'us-east-2', 'us-east-3']
            }
        ]
    },
    {
        label: 'Europe',
        region: [
            {
                label: 'Frankfurt',
                value: 'eu-de',
                zone: ['eu-de-1', 'eu-de-2', 'eu-de-3']
            },
            {
                label: 'London',
                value: 'eu-gb',
                zone: ['eu-gb-1', 'eu-gb-2', 'eu-gb-3']
            },
            {
                label: 'Madrid',
                value: 'eu-es',
                zone: ['eu-es-1', 'eu-es-2', 'eu-es-3']
            }
        ]
    },
    {
        label: 'Asia Pacific',
        region: [
            {
                label: 'Sydney',
                value: 'au-syd',
                zone: ['au-syd-1', 'au-syd-2', 'au-syd-3']
            },
            {
                label: 'Tokyo',
                value: 'jp-tok',
                zone: ['jp-tok-1', 'jp-tok-2', 'jp-tok-3']
            }
        ]
    }
];
const gpu_profiles = [
    {
        label: 'gx2 v100',
        profiles: [
            {
                key: 'gx2-8x64x1v100',
                value: 'gx2-8x64x1v100'
            },
            {
                key: 'gx2-16x128x1v100',
                value: 'gx2-16x128x1v100'
            },
            {
                key: 'gx2-16x128x2v100',
                value: 'gx2-16x128x2v100'
            },
            {
                key: 'gx2-32x256x2v100',
                value: 'gx2-32x256x2v100'
            }
        ]
    },
    {
        label: 'gx2 a100',
        profiles: [
            {
                key: 'gx2-8x64x1v100',
                value: 'gx2-8x64x1v100'
            },
            {
                key: 'gx2-16x128x1v100',
                value: 'gx2-16x128x1v100'
            },
            {
                key: 'gx2-16x128x2v100',
                value: 'gx2-16x128x2v100'
            },
            {
                key: 'gx2-32x256x2v100',
                value: 'gx2-32x256x2v100'
            }
        ]
    },
    {
        label: 'gx3 l4',
        profiles: [
            {
                key: 'gx3-16x80x1l4',
                value: 'gx3-16x80x1l4'
            },
            {
                key: 'gx3-32x160x2l4',
                value: 'gx3-32x160x2l4'
            },
            {
                key: 'gx3-64x320x4l4',
                value: 'gx3-64x320x4l4'
            }
        ]
    }
];
const checkWorkspaceStatus = async (ibmApiKey, setCheckStatusInProgress, setSubmitStatus, setWorkspaceStatusResponse, setServer_details) => {
    const init = {};
    init.method = 'post';
    if (!ibmApiKey) {
        setSubmitStatus({
            status: 'error',
            message: 'Please enter a valid ibm api key'
        });
        setWorkspaceStatusResponse({
            id: '',
            name: '',
            status: '',
            variablestore: []
        });
        setCheckStatusInProgress(false);
        return;
    }
    init.body = JSON.stringify({
        ibm_iam_token: ibmApiKey
    });
    (0,_handler__WEBPACK_IMPORTED_MODULE_0__.requestAPI)('wstatus', init)
        .then(data => {
        if (data.status === 'success') {
            setSubmitStatus({
                status: '',
                message: ''
            });
            console.log(data.data, 'data.data');
            const workspace_state = {
                id: data.data.id,
                name: data.data.name,
                status: data.data.status,
                variablestore: data.data.template_data[0].variablestore
            };
            setWorkspaceStatusResponse(workspace_state);
            store_workspace_state(workspace_state);
        }
        else {
            setSubmitStatus({
                status: 'error',
                message: data.message
            });
            setWorkspaceStatusResponse({
                id: '',
                name: '',
                status: '',
                variablestore: []
            });
            try {
                setCheckStatusInProgress(false);
                window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
                window.localStorage.removeItem(superknowa_server_inforamtion_key);
            }
            catch (error) {
                console.error('Erro in deleting cache!!!!');
            }
        }
        setCheckStatusInProgress(false);
    })
        .catch(reason => {
        setSubmitStatus({
            status: 'error',
            message: reason.toString()
        });
        setWorkspaceStatusResponse({
            id: '',
            name: '',
            status: '',
            variablestore: []
        });
        setCheckStatusInProgress(false);
        try {
            window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
            window.localStorage.removeItem(superknowa_server_inforamtion_key);
            setServerStatusError(setServer_details);
        }
        catch (error) {
            console.error('Erro in deleting cache!!!!');
        }
    });
};
const setServerStatusError = (setServer_details) => {
    setServer_details({
        id: '',
        folder: 'terraform',
        type: 'terraform_v1.5',
        output_values: [
            {
                jupyter_server_url: {
                    type: 'string',
                    value: ''
                },
                public_ip: { type: 'string', value: '' }
            }
        ]
    });
};
const checkServerStatus = async (ibmApiKey, setCheckStatusInProgress, setSubmitStatus, setServer_details) => {
    const init = {};
    init.method = 'post';
    if (!ibmApiKey) {
        setSubmitStatus({
            status: 'error',
            message: 'Please enter a valid ibm api key'
        });
        setServerStatusError(setServer_details);
        setCheckStatusInProgress(false);
        return;
    }
    init.body = JSON.stringify({
        ibm_iam_token: ibmApiKey
    });
    (0,_handler__WEBPACK_IMPORTED_MODULE_0__.requestAPI)('serverstatus', init)
        .then(data => {
        if (data.status === 'success') {
            setSubmitStatus({
                status: '',
                message: ''
            });
            setServer_details(data.data[0]);
            store_server_state(data.data[0]);
        }
        else {
            setSubmitStatus({
                status: 'error',
                message: data.message
            });
        }
        setCheckStatusInProgress(false);
    })
        .catch(reason => {
        setCheckStatusInProgress(false);
        setSubmitStatus({
            status: 'error',
            message: reason.toString()
        });
    });
};
const checkServerActivity = async (ibmApiKey, setCheckStatusInProgress, setSubmitStatus, setActivityLogContent, setActivityLogModal) => {
    const init = {};
    init.method = 'post';
    if (!ibmApiKey) {
        setSubmitStatus({
            status: 'error',
            message: 'Please enter a valid ibm api key'
        });
        setCheckStatusInProgress(false);
        return;
    }
    init.body = JSON.stringify({
        ibm_iam_token: ibmApiKey
    });
    (0,_handler__WEBPACK_IMPORTED_MODULE_0__.requestAPI)('wactivity', init)
        .then(data => {
        if (data.status === 'success') {
            setSubmitStatus({
                status: '',
                message: ''
            });
            // console.log('data = >', data.data);
            const activity = data.data.actions.map((item) => {
                return {
                    action_id: item.action_id,
                    action_name: item.name,
                    status: item.status,
                    performed_at: item.performed_at,
                    performed_by: item.performed_by,
                    log_url: item.templates[0].log_url,
                    message: item.templates[0].message
                };
            });
            setActivityLogContent(JSON.stringify(activity, null, 3));
            setActivityLogModal(true);
        }
        else {
            setSubmitStatus({
                status: 'error',
                message: data.message
            });
        }
        setCheckStatusInProgress(false);
    })
        .catch(reason => {
        setCheckStatusInProgress(false);
        setSubmitStatus({
            status: 'error',
            message: reason.toString()
        });
    });
};
const requestDeleteWorkspace = async (ibmApiKey, setCheckStatusInProgress, setSubmitStatus) => {
    const init = {};
    init.method = 'post';
    if (!ibmApiKey) {
        setSubmitStatus({
            status: 'error',
            message: 'Please enter a valid ibm api key'
        });
        setCheckStatusInProgress(false);
        return;
    }
    init.body = JSON.stringify({
        ibm_iam_token: ibmApiKey
    });
    (0,_handler__WEBPACK_IMPORTED_MODULE_0__.requestAPI)('wdelete', init)
        .then(data => {
        setSubmitStatus({
            status: data.status,
            message: data.status === 'success'
                ? 'Workspace is being deleted. It will take some time to complete the request, please hit the workspace information button or enable auto-refresh to get the latest status'
                : data.message
        });
    })
        .catch(reason => {
        setSubmitStatus({
            status: 'error',
            message: reason.toString()
        });
    })
        .finally(() => {
        try {
            setCheckStatusInProgress(false);
            window.localStorage.removeItem(superknowa_workspace_inforamtion_key);
            window.localStorage.removeItem(superknowa_server_inforamtion_key);
        }
        catch (error) {
            console.error('Erro in deleting cache!!!!');
        }
    });
};
/***
 * This will create workspace and provision a gpu server with user provided input
 */
const provisionWorkspace = async (values, setCheckStatusInProgress, setSubmitStatus, setWorkspaceStatusResponse, setProvisioning) => {
    const init = {};
    init.method = 'post';
    init.body = JSON.stringify(values);
    const existing_workspace = get_workspace_state();
    let endpoint_api = 'workspace'; // create workspace
    if (existing_workspace.id) {
        endpoint_api = 'wupdate'; // update workspace
    }
    (0,_handler__WEBPACK_IMPORTED_MODULE_0__.requestAPI)(endpoint_api, init)
        .then(data => {
        setCheckStatusInProgress(false);
        setSubmitStatus({
            status: 'success',
            message: 'The request has been successfully submitted. It may take some time to process. Please wait patiently for the request to complete.'
        });
        const server_response = {
            id: data.data.id,
            name: data.data.name,
            status: data.data.status,
            variablestore: data.data.template_data[0].variablestore
        };
        setWorkspaceStatusResponse(server_response);
        store_workspace_state(server_response);
        setProvisioning(true);
    })
        .catch(reason => {
        setCheckStatusInProgress(false);
        setSubmitStatus({
            status: 'error',
            message: reason.toString()
        });
        if (endpoint_api !== 'wupdate') {
            // if newly created workspace and gives exception then set the error status
            setWorkspaceStatusResponse({
                id: '',
                name: '',
                status: 'error',
                variablestore: []
            });
        }
        // `The superknowa_ext_byom server extension appears to be missing.\n${reason}`
    });
};
const superknowa_workspace_inforamtion_key = 'superknowa_workspace_inforamtion';
const superknowa_server_inforamtion_key = 'superknowa_server_inforamtion_key';
const store_workspace_state = (data) => {
    window.localStorage.setItem(superknowa_workspace_inforamtion_key, JSON.stringify(data));
};
const get_workspace_state = () => {
    const newObject = window.localStorage.getItem(superknowa_workspace_inforamtion_key);
    if (newObject) {
        return JSON.parse(newObject);
    }
    else {
        return {
            id: '',
            name: '',
            status: '',
            variablestore: [
                {
                    name: '',
                    value: ''
                }
            ]
        };
    }
};
const store_server_state = (data) => {
    window.localStorage.setItem(superknowa_server_inforamtion_key, JSON.stringify(data));
};
const get_server_state = () => {
    const newObject = window.localStorage.getItem(superknowa_server_inforamtion_key);
    if (newObject) {
        return JSON.parse(newObject);
    }
    else {
        return {
            id: '',
            folder: 'terraform',
            type: 'terraform_v1.5',
            output_values: [
                {
                    jupyter_server_url: {
                        type: 'string',
                        value: ''
                    },
                    public_ip: { type: 'string', value: '' }
                }
            ]
        };
    }
};
const parse_workspace_name = (workspace_name) => {
    if (!workspace_name) {
        return '';
    }
    const match = workspace_name.match(/superknowa-byom-(.*?)-workspace/);
    if (match && match.length > 1) {
        const extractedString = match[1];
        return extractedString;
    }
    else {
        return '';
    }
};


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'superknowa-ext-byom', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./widget */ "./lib/widget.js");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);





/**
 * The command IDs used by the react-widget plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.create = 'create-superknowa-widget';
})(CommandIDs || (CommandIDs = {}));
/**
 * Initialization data for the superknowa-ext-byom extension.
 */
const plugin = {
    id: 'superknowa-ext-byom:plugin',
    description: 'Superknowa BYOM Jupyterlab extension to provsion a development environment',
    autoStart: true,
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher],
    activate: (app, launcher) => {
        console.log('JupyterLab extension superknowa-ext-byom is being activated!');
        const { commands } = app;
        const command = CommandIDs.create;
        commands.addCommand(command, {
            caption: 'Bring your own model superknowa byom',
            label: 'Superknowa BYOM',
            icon: args => (args['isPalette'] ? undefined : _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.listIcon),
            execute: () => {
                const content = new _widget__WEBPACK_IMPORTED_MODULE_3__.GPUProvisionWidget();
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.title.label = 'Superknowa BYOM';
                widget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.listIcon;
                app.shell.add(widget, 'main');
            }
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('test')
            .then(data => {
            console.log(data);
        })
            .catch(reason => {
            console.error(`The superknowa_ext_byom server extension appears to be missing.\n${reason}`);
        });
        if (launcher) {
            launcher.add({
                command
            });
        }
        console.log('JupyterLab extension superknowa-ext-byom is activated!');
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/widget.js":
/*!***********************!*\
  !*** ./lib/widget.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GPUProvisionWidget: () => (/* binding */ GPUProvisionWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/icons-material/VisibilityOff */ "./node_modules/@mui/icons-material/VisibilityOff.js");
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/icons-material/Visibility */ "./node_modules/@mui/icons-material/Visibility.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _IBMIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./IBMIcon */ "./lib/IBMIcon.js");
/* harmony import */ var _mui_icons_material_RefreshOutlined__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @mui/icons-material/RefreshOutlined */ "./node_modules/@mui/icons-material/RefreshOutlined.js");
/* harmony import */ var _mui_icons_material_RemoveCircleOutlineOutlined__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/icons-material/RemoveCircleOutlineOutlined */ "./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js");
/* harmony import */ var _mui_icons_material_StorageOutlined__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @mui/icons-material/StorageOutlined */ "./node_modules/@mui/icons-material/StorageOutlined.js");
/* harmony import */ var _mui_icons_material_CreateOutlined__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/icons-material/CreateOutlined */ "./node_modules/@mui/icons-material/CreateOutlined.js");
/* harmony import */ var _mui_icons_material_LoopOutlined__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/LoopOutlined */ "./node_modules/@mui/icons-material/LoopOutlined.js");
/* harmony import */ var _mui_icons_material_SyncDisabledOutlined__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/SyncDisabledOutlined */ "./node_modules/@mui/icons-material/SyncDisabledOutlined.js");
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @mui/icons-material/Close */ "./node_modules/@mui/icons-material/Close.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "webpack/sharing/consume/default/formik/formik");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! yup */ "webpack/sharing/consume/default/yup/yup");
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _api_schematic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./api/schematic */ "./lib/api/schematic.js");
















/**
 * React component for a counter.
 *
 * @returns The React component
 */
const GPUProvisionComponent = () => {
    const [showPassword, setShowPassword] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [showPat, setShowPat] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [ibm_iam_token, setIbm_iam_token] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [server_details, setServer_details] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(_api_schematic__WEBPACK_IMPORTED_MODULE_5__.get_server_state);
    const [checkStatusInProgress, setCheckStatusInProgress] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [activityLogModal, setActivityLogModal] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [activityLogContent, setActivityLogContent] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [submitStatus, setSubmitStatus] = react__WEBPACK_IMPORTED_MODULE_2___default().useState({
        status: '',
        message: ''
    });
    const handleClickShowPassword = () => setShowPassword(show => !show);
    const handleClickShowGithubPAT = () => setShowPat(show => !show);
    const [openRemoveWorkspaceAgree, setOpenRemoveWorkspaceAgree] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const handleRemoveWorkspaceOpen = () => {
        setOpenRemoveWorkspaceAgree(true);
    };
    const handleRemoveWorkspaceClose = () => {
        setOpenRemoveWorkspaceAgree(false);
    };
    const [openCreateWorkspaceAgree, setOpenCreateWorkspaceAgree] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const handleCreateWorkspaceOpen = () => {
        setOpenCreateWorkspaceAgree(true);
    };
    const handleCreateWorkspaceClose = () => {
        setOpenCreateWorkspaceAgree(false);
    };
    const [workspaceStatusResponse, setWorkspaceStatusResponse] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(_api_schematic__WEBPACK_IMPORTED_MODULE_5__.get_workspace_state);
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const handleMouseDownShowPat = (event) => {
        event.preventDefault();
    };
    const validationSchema = yup__WEBPACK_IMPORTED_MODULE_4__.object({
        workspace_name: yup__WEBPACK_IMPORTED_MODULE_4__.string()
            .required('Workspace name is required')
            .matches(/^(\S+$)/g, 'Workspace name can not contain only blankspaces')
            .matches(/^[^!@#$%^&*+=<>:;|~_-]*$/, {
            message: 'Workspace name can not contain any symbols'
        })
            .matches(/^[a-z]+$/, {
            message: 'Lower case character only'
        }),
        ibm_iam_token: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('IBM API key is required'),
        githubPAT: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('Github API key required'),
        ssh_key_name: yup__WEBPACK_IMPORTED_MODULE_4__.string()
            .required('Please enter a valid ssh key based on the region you select, otherwise you will not be able to access the VM after it provisioned.'),
        vpc_vsi_profile_name: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('Please select a GPU profile'),
        region: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('Please select a region'),
        zone: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('Please select a zone'),
        resource_group_name: yup__WEBPACK_IMPORTED_MODULE_4__.string().required('Resource group is required'),
        jupyter_lab_image: yup__WEBPACK_IMPORTED_MODULE_4__.string()
            .required('Jupyter image name is required')
            .matches(/^(quay\.io\/[a-zA-Z0-9]*\/[a-zA-Z0-9-_]*:[a-zA-Z0-9-_.]*)/g, 'Please enter a valid jupyter lab image. A valid jupyter image format is quay.io/<REPOSITORY>/<IMAGE>:<TAG>')
    });
    const formik = (0,formik__WEBPACK_IMPORTED_MODULE_3__.useFormik)({
        initialValues: {
            workspace_name: (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.parse_workspace_name)(workspaceStatusResponse.name),
            ssh_key_name: '',
            ibm_iam_token: '',
            githubPAT: '',
            vpc_vsi_image_name: 'ibm-ubuntu-22-04-3-minimal-amd64-1',
            vpc_vsi_profile_name: 'gx3-16x80x1l4',
            resource_group_name: 'Default',
            jupyter_lab_image: 'quay.io/jupyter/datascience-notebook:python-3.11',
            zone: 'us-south-1',
            region: 'us-south'
        },
        validationSchema: validationSchema,
        onSubmit: values => {
            handleCreateWorkspaceOpen();
        }
    });
    const handleWorkspaceStatus = async () => {
        // reset the progress bar and submit status
        setCheckStatusInProgress(true);
        setSubmitStatus({
            status: '',
            message: ''
        });
        await (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.checkWorkspaceStatus)(ibm_iam_token, setCheckStatusInProgress, setSubmitStatus, setWorkspaceStatusResponse, setServer_details);
        // set the progress bar and submit status based on the response
    };
    const handleServerStatus = async () => {
        // reset the progress bar and submit status
        setCheckStatusInProgress(true);
        setSubmitStatus({
            status: '',
            message: ''
        });
        await (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.checkServerStatus)(ibm_iam_token, setCheckStatusInProgress, setSubmitStatus, setServer_details);
    };
    const handleServerActivityLog = async () => {
        // reset the progress bar and submit status
        setCheckStatusInProgress(true);
        setSubmitStatus({
            status: '',
            message: ''
        });
        await (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.checkServerActivity)(ibm_iam_token, setCheckStatusInProgress, setSubmitStatus, setActivityLogContent, setActivityLogModal);
    };
    const handleDeleteWorkspace = async () => {
        // reset the progress bar and submit status
        setCheckStatusInProgress(true);
        handleRemoveWorkspaceClose();
        setSubmitStatus({
            status: '',
            message: ''
        });
        await (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.requestDeleteWorkspace)(ibm_iam_token, setCheckStatusInProgress, setSubmitStatus);
    };
    const handleProvisionWorkspace = async () => {
        // reset the progress bar and submit status
        handleCreateWorkspaceClose();
        setCheckStatusInProgress(true);
        setSubmitStatus({
            status: '',
            message: ''
        });
        try {
            await (0,_api_schematic__WEBPACK_IMPORTED_MODULE_5__.provisionWorkspace)(formik.values, setCheckStatusInProgress, setSubmitStatus, setWorkspaceStatusResponse, setProvisioning);
        }
        catch {
            console.log('error in calling api');
            /* empty */
        }
    };
    const [customizeSettings, setCustomizeSettings] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [autoRefresh, setAutoRefresh] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [provisioning, setProvisioning] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const handleCustomizeSettings = (event) => {
        setCustomizeSettings(event.target.checked);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        const intervalId = setInterval(() => {
            if (autoRefresh && ibm_iam_token) {
                handleWorkspaceStatus();
            }
        }, 1 * 60 * 1000);
        // Cleanup function to clear interval when component unmounts
        return () => clearInterval(intervalId);
    }, [autoRefresh, ibm_iam_token]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {
        const intervalId = setInterval(() => {
            if (provisioning && ibm_iam_token) {
                if (workspaceStatusResponse.status === 'ACTIVE' ||
                    workspaceStatusResponse.status === 'FAILED') {
                    console.log('active status detected');
                    setProvisioning(false);
                }
                else {
                    handleWorkspaceStatus();
                }
            }
        }, 1 * 65 * 1000);
        // Cleanup function to clear interval when component unmounts
        return () => clearInterval(intervalId);
    }, [provisioning, ibm_iam_token, workspaceStatusResponse]);
    const startStopAutoRefresh = (event) => {
        setAutoRefresh(event.target.checked);
    };
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', justifyContent: 'space-between' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', justifyContent: 'flex-start' },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_IBMIcon__WEBPACK_IMPORTED_MODULE_6__["default"], null)),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { mt: '12px', ml: '5px', variant: "h6", height: '30px', noWrap: true, sx: {
                        display: { xs: 'none', md: 'flex' },
                        textDecoration: 'none'
                    } }, "Ecosystem Engineering")),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { mt: '12px', ml: '5px', variant: "h6", height: '30px', noWrap: true, sx: {
                    display: { xs: 'none', md: 'flex' },
                    textDecoration: 'none'
                } }, "BYOM Starter"),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormGroup, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, { control: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Checkbox, { color: "success", checked: autoRefresh, onChange: startStopAutoRefresh, icon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_SyncDisabledOutlined__WEBPACK_IMPORTED_MODULE_7__["default"], null), checkedIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_LoopOutlined__WEBPACK_IMPORTED_MODULE_8__["default"], null) }), label: "Auto refresh" }))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', mt: '50px', flexDirection: 'row', alignContent: 'center', justifyContent: 'center' },
            submitStatus.status === 'success' && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { sx: { marginBottom: '20px' }, variant: "outlined", severity: "success" }, submitStatus.message)),
            submitStatus.status === 'error' && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { sx: { marginBottom: '20px' }, variant: "outlined", severity: "error" }, submitStatus.message))),
        checkStatusInProgress && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row', alignContent: 'center', justifyContent: 'center', ml: '50px', mr: '50px' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.LinearProgress, { sx: { width: '100%' }, color: "success" }))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', ml: '50px', mr: '50px', flexDirection: 'row', justifyContent: 'space-between' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: { width: '49%' } },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardHeader, { titleTypographyProps: { variant: 'subtitle2' }, title: "Provision a GPU server in IBM Cloud for training, inference, and deploying an LLM model." }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement("form", { onSubmit: formik.handleSubmit },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, { style: { padding: '10px' } },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { margin: "dense", sx: {
                                    width: '60ch',
                                    marginBottom: '10px'
                                }, id: "workspace_name", name: "workspace_name", label: "Workspace name", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.workspace_name, inputProps: {
                                    style: {
                                        height: 10
                                    }
                                }, error: formik.touched.workspace_name &&
                                    Boolean(formik.errors.workspace_name) }),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null, formik.errors.workspace_name &&
                                formik.touched.workspace_name && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.workspace_name.toString()))),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '60ch' }, variant: "outlined" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "ibm_iam_token", sx: { fontSize: '14px' } }, "IBM Api key"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.OutlinedInput, { margin: "dense", sx: { height: '40px' }, id: "ibm_iam_token", type: showPassword ? 'text' : 'password', endAdornment: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end" },
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { "aria-label": "toggle password visibility", onClick: handleClickShowPassword, onMouseDown: handleMouseDownPassword, edge: "end" }, showPassword ? react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10__["default"], null))), label: "Api Key", value: formik.values.ibm_iam_token, onChange: e => {
                                        setIbm_iam_token(e.target.value);
                                        formik.handleChange(e);
                                    }, onBlur: formik.handleBlur, name: "ibm_iam_token" }),
                                formik.errors.ibm_iam_token &&
                                    formik.touched.ibm_iam_token && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.ibm_iam_token))),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '60ch', mt: '10px' }, variant: "outlined" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "githubPAT", sx: { fontSize: '14px' } }, "Github access token"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.OutlinedInput, { margin: "dense", sx: { height: '40px' }, id: "githubPAT", name: "githubPAT", type: showPat ? 'text' : 'password', endAdornment: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end" },
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { "aria-label": "toggle password visibility", onClick: handleClickShowGithubPAT, onMouseDown: handleMouseDownShowPat, edge: "end" }, showPat ? react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_10__["default"], null))), label: "Github access token", value: formik.values.githubPAT, onChange: formik.handleChange, onBlur: formik.handleBlur }),
                                formik.errors.githubPAT && formik.touched.githubPAT && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.githubPAT))),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { margin: "dense", sx: {
                                    width: '60ch',
                                    marginTop: '10px'
                                }, id: "ssh_key_name", name: "ssh_key_name", label: "ssh key name", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.ssh_key_name, inputProps: {
                                    style: {
                                        height: 10
                                    }
                                }, error: formik.touched.ssh_key_name &&
                                    Boolean(formik.errors.ssh_key_name) }),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null, formik.errors.ssh_key_name &&
                                formik.touched.ssh_key_name && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.ssh_key_name)))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormGroup, null,
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, { control: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Checkbox, { color: "success", checked: customizeSettings, onChange: handleCustomizeSettings }), label: "Customize default settings" })),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, { style: {
                                padding: '10px',
                                display: customizeSettings ? 'block' : 'none'
                            } },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', ml: '5px', mr: '5px', flexDirection: 'column' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row', marginTop: '15px' },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { minWidth: 120 } },
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "region", sx: { fontSize: '14px' } }, "Region"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, native: true, id: "region", name: "region", label: "Region", onChange: e => {
                                                e.preventDefault();
                                                formik.handleChange(e);
                                                formik.setFieldValue('zone', '');
                                            }, onBlur: formik.handleBlur, value: formik.values.region },
                                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement("option", { "aria-label": "None", value: "" }),
                                            _api_schematic__WEBPACK_IMPORTED_MODULE_5__.region_zone.map((reg, _inx) => {
                                                return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("optgroup", { key: _inx, label: reg.label }, reg.region.map((reg_name, _rinx) => {
                                                    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("option", { key: _rinx, value: reg_name.value }, reg_name.label));
                                                })));
                                            })),
                                        formik.errors.region && formik.touched.region && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("div", null, formik.errors.region))),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: {
                                            width: '150px',
                                            marginLeft: '10px',
                                            marginRight: '10px'
                                        }, variant: "outlined" },
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "zone-select-label", sx: { fontSize: '14px' } }, "Zone"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, labelId: "zone-select-label", id: "zone", name: "zone", label: "Zone", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.zone }, _api_schematic__WEBPACK_IMPORTED_MODULE_5__.region_zone
                                            .flatMap(reg => reg.region)
                                            .filter(zn => zn.value === formik.values.region)
                                            .flatMap(item => item.zone)
                                            .map((fzone, _inx) => {
                                            return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { key: _inx, value: fzone }, fzone));
                                        })),
                                        formik.errors.zone && formik.touched.zone && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.zone)))),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '50ch', marginTop: '15px' }, variant: "outlined" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "image-vsi-select-label", sx: { fontSize: '14px' } }, "OS Profile"),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, labelId: "image-vsi-select-label", id: "vpc_vsi_image_name", name: "vpc_vsi_image_name", label: "OS Profile", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.vpc_vsi_image_name },
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-22-04-3-minimal-amd64-1' }, "ibm-ubuntu-22-04-3-minimal-amd64-1"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-22-04-3-minimal-amd64-2' }, "ibm-ubuntu-22-04-3-minimal-amd64-2"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-20-04-6-minimal-amd64-3' }, "ibm-ubuntu-20-04-6-minimal-amd64-3"))),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '50ch', marginTop: '15px' }, variant: "outlined" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "demo-simple-select-label", sx: { fontSize: '14px' } }, "GPU Profile"),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { native: true, sx: { height: '40px', fontSize: '14px' }, labelId: "demo-simple-select-label", id: "vpc_vsi_profile_name", name: "vpc_vsi_profile_name", label: "GPU Profile", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.vpc_vsi_profile_name }, _api_schematic__WEBPACK_IMPORTED_MODULE_5__.gpu_profiles.map((profile, _inx) => {
                                        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("optgroup", { key: _inx, label: profile.label }, profile.profiles.map((item, _rinx) => {
                                            return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("option", { key: _rinx, value: item.value }, item.value));
                                        })));
                                    }))),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { margin: "dense", sx: {
                                        width: '30ch',
                                        marginTop: '15px'
                                    }, id: "resource_group_name", name: "resource_group_name", label: "Resource Group", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.resource_group_name, inputProps: {
                                        style: {
                                            height: 10
                                        }
                                    }, error: formik.touched.resource_group_name &&
                                        Boolean(formik.errors.resource_group_name) }),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null, formik.errors.resource_group_name &&
                                    formik.touched.resource_group_name && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.resource_group_name))),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { margin: "dense", sx: {
                                        width: '60ch',
                                        marginTop: '15px'
                                    }, id: "jupyter_lab_image", name: "jupyter_lab_image", label: "Jupyter Lab Image", onChange: formik.handleChange, onBlur: formik.handleBlur, value: formik.values.jupyter_lab_image, inputProps: {
                                        style: {
                                            height: 10
                                        }
                                    }, error: formik.touched.jupyter_lab_image &&
                                        Boolean(formik.errors.jupyter_lab_image) }),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null, formik.errors.jupyter_lab_image &&
                                    formik.touched.jupyter_lab_image && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormHelperText, { error: true }, formik.errors.jupyter_lab_image)))))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardActions, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { marginTop: '15px', display: 'flex', flexDirection: 'row' },
                            !workspaceStatusResponse.id && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Deploy a GPU server instance" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { disabled: checkStatusInProgress || provisioning, variant: "outlined", size: "small", sx: {
                                        fontSize: '14px',
                                        mr: '10px',
                                        textTransform: 'none'
                                    }, type: "submit", color: "success", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_CreateOutlined__WEBPACK_IMPORTED_MODULE_11__["default"], null) }, "Provision"))),
                            workspaceStatusResponse.id && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Update the GPU server instance" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { disabled: checkStatusInProgress || provisioning, variant: "outlined", size: "small", sx: {
                                            fontSize: '14px',
                                            mr: '10px',
                                            textTransform: 'none'
                                        }, type: "submit", color: "success", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_CreateOutlined__WEBPACK_IMPORTED_MODULE_11__["default"], null) }, "Update Server Deployment")),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Delete the GPU server instance" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_RemoveCircleOutlineOutlined__WEBPACK_IMPORTED_MODULE_12__["default"], null), onClick: handleRemoveWorkspaceOpen, sx: {
                                            fontSize: '14px',
                                            mr: '10px',
                                            textTransform: 'none'
                                        }, size: "small", disabled: checkStatusInProgress || provisioning, color: "success" }, "Remove")),
                                provisioning && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { display: 'flex', ml: '5px' } },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, null))))))))),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: { width: '49%' } },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardHeader, { titleTypographyProps: { variant: 'subtitle2' }, title: "Workspace details" }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardActions, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Click the button to get latest workspace status" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_RefreshOutlined__WEBPACK_IMPORTED_MODULE_13__["default"], null), onClick: handleWorkspaceStatus, sx: { fontSize: '14px', mr: '10px', textTransform: 'none' }, size: "small", color: "success", disabled: checkStatusInProgress }, "Workspace information")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Click the button to get latest server details" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_StorageOutlined__WEBPACK_IMPORTED_MODULE_14__["default"], null), onClick: handleServerStatus, sx: { fontSize: '14px', mr: '10px', textTransform: 'none' }, size: "small", color: "success", disabled: checkStatusInProgress }, "Server information")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Click the button to get server activity log" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_StorageOutlined__WEBPACK_IMPORTED_MODULE_14__["default"], null), onClick: handleServerActivityLog, sx: { fontSize: '14px', mr: '10px', textTransform: 'none' }, size: "small", color: "success", disabled: checkStatusInProgress }, "Activity log")))),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, null,
                    workspaceStatusResponse.id && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Id:")),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.id))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Name:")),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.name))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Status:")),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.status))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Url:")),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Link, { href: 'https://cloud.ibm.com/schematics/workspaces/' +
                                        workspaceStatusResponse.id +
                                        '/settings', underline: "hover", target: "_blank" },
                                    "https://cloud.ibm.com/schematics/workspaces/",
                                    workspaceStatusResponse.id,
                                    "/settings"))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableContainer, { component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Table, { size: "small", "aria-label": "Variable details" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableHead, null,
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Name"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Value"))),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableBody, null, workspaceStatusResponse.variablestore.map((row) => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, { key: row?.name, sx: {
                                        '&:last-child td, &:last-child th': { border: 0 }
                                    } },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, row.name),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, row.value))))))))),
                    server_details.id && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "h6", mb: '5px', mt: '10px' }, "Server Details"),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableContainer, { component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Table, { size: "small", "aria-label": "Variable details" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableBody, null,
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Id"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, server_details.id)),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Jupyter server url"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, server_details.output_values[0].jupyter_server_url
                                            .value)),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Server IP"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, server_details.output_values[0].public_ip.value)),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Login command"),
                                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null,
                                            "ssh root@",
                                            server_details.output_values[0].public_ip.value)))))))))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: openRemoveWorkspaceAgree, onClose: handleRemoveWorkspaceClose, "aria-labelledby": "alert-dialog-remove-workspace-title", "aria-describedby": "alert-dialog-remove-workspace-description" },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, { id: "alert-dialog-create-workspace-title" }, 'Are you sure want to remove this GPU server?'),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContentText, { id: "alert-dialog-create-workspace-description" }, "This action will delete the workspace and the GPU server. All of the resources will be removed and cannot be rolled back.")),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleRemoveWorkspaceClose }, "No"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleDeleteWorkspace, autoFocus: true }, "Yes"))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: openCreateWorkspaceAgree, onClose: handleRemoveWorkspaceClose, "aria-labelledby": "alert-dialog-title", "aria-describedby": "alert-dialog-create-workspace" },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, { dividers: true },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableContainer, { component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "subtitle1", gutterBottom: true, component: "div" }, "Below are the details for provisioning a GPU server."),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Table, { size: "small", "aria-label": "Variable details" },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableHead, null,
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Name"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Value"))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableBody, null,
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Ssh Key"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.ssh_key_name)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Region"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.region)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Zone"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.zone)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "GPU Profile"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.vpc_vsi_profile_name)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "OS Profile"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.vpc_vsi_image_name)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Resourse Group"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.resource_group_name)),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Jupyter Lab Image"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, formik.values.jupyter_lab_image))))),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContentText, { id: "alert-dialog-create-workspace-description", variant: "subtitle2", mt: '10px' },
                    "There will be a cost associated with this environment. Please review and confirm it before submitting the request. Visit the URL",
                    ' ',
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Link, { href: "https://www.ibm.com/cloud/cloud-calculator", underline: "hover", target: "_blank" }, "https://www.ibm.com/cloud/cloud-calculator"),
                    ' ',
                    "to review the associated costs.")),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, { id: "alert-dialog-create-workspace-title" }, 'Are you sure want to create this GPU server in IBM Cloud?'),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleCreateWorkspaceClose }, "No"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleProvisionWorkspace, autoFocus: true }, "Yes"))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Modal, { open: activityLogModal, onClose: () => setActivityLogModal(false) },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                    width: 800,
                    bgcolor: 'background.paper',
                    border: '2px solid #000',
                    boxShadow: 24,
                    p: 4
                } },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row', justifyContent: 'space-between' },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { id: "modal-modal-title", variant: "h6", component: "h2" }, "Server activity log"),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { "aria-label": "delete", size: "large", onClick: () => setActivityLogModal(false) },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_15__["default"], null))),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { id: "modal-modal-description", sx: { mt: 2 } },
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("pre", { style: {
                            textWrap: 'wrap'
                        } }, activityLogContent !== '' && activityLogContent))))));
};
/**
 * A Counter Lumino Widget that wraps a GPUProvisionComponent.
 */
class GPUProvisionWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    /**
     * Constructs a new GPUProvisionWidget.
     */
    constructor() {
        super();
        this.addClass('jp-react-widget');
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_2___default().createElement(GPUProvisionComponent, null);
    }
}


/***/ }),

/***/ "./node_modules/@mui/icons-material/Close.js":
/*!***************************************************!*\
  !*** ./node_modules/@mui/icons-material/Close.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close');

/***/ }),

/***/ "./node_modules/@mui/icons-material/CreateOutlined.js":
/*!************************************************************!*\
  !*** ./node_modules/@mui/icons-material/CreateOutlined.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM5.92 19H5v-.92l9.06-9.06.92.92zM20.71 5.63l-2.34-2.34c-.2-.2-.45-.29-.71-.29s-.51.1-.7.29l-1.83 1.83 3.75 3.75 1.83-1.83c.39-.39.39-1.02 0-1.41"
}), 'CreateOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/LoopOutlined.js":
/*!**********************************************************!*\
  !*** ./node_modules/@mui/icons-material/LoopOutlined.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8m0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4z"
}), 'LoopOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/RefreshOutlined.js":
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/RefreshOutlined.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z"
}), 'RefreshOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M7 11v2h10v-2zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8"
}), 'RemoveCircleOutlineOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/StorageOutlined.js":
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/StorageOutlined.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M2 20h20v-4H2zm2-3h2v2H4zM2 4v4h20V4zm4 3H4V5h2zm-4 7h20v-4H2zm2-3h2v2H4z"
}), 'StorageOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/SyncDisabledOutlined.js":
/*!******************************************************************!*\
  !*** ./node_modules/@mui/icons-material/SyncDisabledOutlined.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M10 6.35V4.26c-.66.17-1.29.43-1.88.75l1.5 1.5c.13-.05.25-.11.38-.16M20 12c0-2.21-.91-4.2-2.36-5.64L20 4h-6v6l2.24-2.24C17.32 8.85 18 10.34 18 12c0 .85-.19 1.65-.51 2.38l1.5 1.5C19.63 14.74 20 13.41 20 12M4.27 4 2.86 5.41l2.36 2.36C4.45 8.99 4 10.44 4 12c0 2.21.91 4.2 2.36 5.64L4 20h6v-6l-2.24 2.24C6.68 15.15 6 13.66 6 12c0-1 .25-1.94.68-2.77l8.08 8.08c-.25.13-.5.24-.76.34v2.09c.8-.21 1.55-.54 2.23-.96l2.58 2.58 1.41-1.41z"
}), 'SyncDisabledOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/Visibility.js":
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/Visibility.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5M12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5m0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3"
}), 'Visibility');

/***/ }),

/***/ "./node_modules/@mui/icons-material/VisibilityOff.js":
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/VisibilityOff.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7M2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2m4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3z"
}), 'VisibilityOff');

/***/ }),

/***/ "./node_modules/@mui/icons-material/utils/createSvgIcon.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/utils/createSvgIcon.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


'use client';

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "default", ({
  enumerable: true,
  get: function () {
    return _utils.createSvgIcon;
  }
}));
var _utils = __webpack_require__(/*! @mui/material/utils */ "./node_modules/@mui/material/utils/index.js");

/***/ })

}]);
//# sourceMappingURL=lib_index_js.ffe4ab2b09ff3a48216d.js.map