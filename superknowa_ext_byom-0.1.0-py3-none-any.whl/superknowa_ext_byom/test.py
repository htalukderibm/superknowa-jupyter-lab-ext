from ibm_schematics.schematics_v1 import SchematicsV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import requests

class Schematics:
    
    def __init__(self,ibm_iam_token):
        self.ibm_iam_token = ibm_iam_token
        authenticator = IAMAuthenticator(self.ibm_iam_token)
        service = SchematicsV1(authenticator=authenticator)
        service.set_service_url('https://schematics.cloud.ibm.com')
        self.schematic_service = service
    
    def get_token(self):
        # Set the URL for the IBM Cloud IAM token endpoint
        url = 'https://iam.cloud.ibm.com/identity/token'

        # Set the headers for the POST request
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }

        # Set the data for the POST request
        data = {
            'grant_type': 'urn:ibm:params:oauth:grant-type:apikey',
            'apikey': self.ibm_iam_token
        }

        # Make the POST request
        response = requests.post(url, headers=headers, data=data, auth=('bx', 'bx'))
        return response.json()
    
    def apply_script(self,w_id):
        refresh_token = self.get_token()['refresh_token']
        response = self.schematic_service.apply_workspace_command(w_id=w_id, refresh_token=refresh_token)
        return response
    
    def get_workspace_list(self):
        schematics_service = self.service()
        result = self.schematic_service.list_workspaces().get_result()
        return result

    def create_workspace(self,data: dict):

        vpc_vsi_profile_name = data["vpc_vsi_profile_name"]
        vpc_vsi_image_name = data["vpc_vsi_image_name"]
        region = data["region"]
        zone = data["zone"]
        ssh_key_name = data["ssh_key_name"]

        template_source_data_request_model = {}
        template_source_data_request_model['folder'] = '.'
        template_source_data_request_model['compact'] = True
        template_source_data_request_model['type'] = 'terraform_v1.5'
        template_source_data_request_model['variablestore'] = [

                {
                    "name": "resource_group",
                    "value": "poc"
                },
                {
                    "name": "vpc",
                    "value": "byom-dev"
                },
                {
                    "name": "keys",
                    "value": f"[\"{ssh_key_name}\"]"
                },
                {
                    "name": "region",
                    "value": region
                },
                {
                    "name": "zone",
                    "value": zone
                },
                {
                    "name": "vpc_vsi_image_name",
                    "value": vpc_vsi_image_name
                },
                {
                    "name": "vpc_vsi_profile_name",
                    "value": vpc_vsi_profile_name
                }
        ]

        template_repo_request_model = {}
        template_repo_request_model['url'] = 'https://github.ibm.com/hcbt/SuperKnowa-BYOM/tree/main/terraform'
        #template_repo_request_model['branch'] = 'main'
        try:
            workspace_response = self.schematic_service.create_workspace(
                description="superknowa bring your own model schematic workspace", 
                name="superknowa-v2-workspace-02",
                template_data=[template_source_data_request_model],
                template_repo=template_repo_request_model,
                type=['terraform_v1.5'],
                location=region,
                resource_group="poc",
                tags=['env:poc'],
                x_github_token='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',
            ).get_result()


            

            return workspace_response

        except Exception as x:
            print(str(x))


data = {}
data['ibm_iam_token'] = 'Qsdfsdf79iBGsY1isUxxyBNWA3PsNaPMTppiS-GDZnU3XeExE'
data["vpc_vsi_profile_name"] = 'gx2-8x64x1v100'
data["vpc_vsi_image_name"] = 'ibm-ubuntu-22-04-3-minimal-amd64-1'
data["region"] = 'us-south'
data["zone"] = 'us-south-1'
data["ssh_key_name"] = 'htalukder'

sc = Schematics(data['ibm_iam_token'])
workspace = sc.create_workspace(data=data)



## sc.apply_script(w_id="us-south.workspace.superknowa-v2-workspace-01.1e98ea26")

"""
response = sc.create_workspace(data=data)
print("===========================================================")
print(response['id'])
print(response['name'])
print(response['crn'])
print("===========================================================")
print(response)
"""