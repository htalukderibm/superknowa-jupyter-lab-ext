from threading import Timer


def truth():
    print("Python rocks!")


t = Timer(15, truth).start()
print("how are you??")
