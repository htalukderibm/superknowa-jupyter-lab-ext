(self["webpackChunksuperknowa_ext_byom"] = self["webpackChunksuperknowa_ext_byom"] || []).push([["lib_index_js"],{

/***/ "./lib/IBMIcon.js":
/*!************************!*\
  !*** ./lib/IBMIcon.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ IBMIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material/SvgIcon */ "./node_modules/@mui/material/SvgIcon/SvgIcon.js");


function IBMIcon() {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_1__["default"], { style: { height: '40px', width: '70px' } },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M0 9.6v.876h6.23V9.6zm7.11 0v.876h8.876c0 0-.907-.876-2.107-.876zm10.618 0v.876h5.37l-.32-.876zm9.22 0l-.32.876h5.32V9.6zM0 11.303v.876h6.23v-.876zm7.11.001v.875h9.906c0 0-.116-.674-.317-.875zm10.618 0v.875h5.96l-.295-.875zm8.583 0l-.295.875h5.935v-.875zM1.8 13.006v.877h2.697v-.877zm7.11 0v.877H11.6v-.877zm5.32 0v.877h2.698c0 0 .17-.463.17-.877zm5.296 0v.877H24.3l-.32-.877zm6.205 0l-.32.877H30.2v-.877zM1.8 14.71v.876h2.697v-.876zm7.11 0v.876h6.9c0 0 .576-.45.76-.876zm10.618 0v.876h2.697V15.1l.17.487h4.94l.184-.487v.487H30.2v-.876h-5.064l-.27.742-.27-.742zM1.8 16.414v.876h2.697v-.876zm7.11 0v.876h7.65c-.184-.425-.76-.876-.76-.876zm10.618 0v.876h2.697v-.876zm3.188 0l.326.876h3.705l.3-.876zm4.806 0v.876H30.2v-.876zM1.8 18.117v.876h2.697v-.876zm7.11 0v.876H11.6v-.876zm5.32 0v.876h2.87c0-.413-.17-.876-.17-.876zm5.296 0v.876h2.697v-.876zm3.8 0l.316.876h2.484l.32-.876zm4.194 0v.876H30.2v-.876zM.05 19.82v.877h6.23v-.877zm7.063 0v.877h9.59c.202-.2.317-.877.317-.877zm10.666 0v.877h4.44v-.877zm6.155 0l.325.877h1.264l.305-.877zm3.58 0v.877H32v-.877zM.05 21.524v.876h6.23v-.876zm7.063 0v.875h6.77c1.2 0 2.108-.875 2.108-.875zm10.666 0v.876h4.44v-.876zm6.77 0l.313.873.054.001.318-.875zm2.964 0v.876H32v-.876z" })));
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'superknowa-ext-byom', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./widget */ "./lib/widget.js");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);





/**
 * The command IDs used by the react-widget plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.create = 'create-superknowa-widget';
})(CommandIDs || (CommandIDs = {}));
/**
 * Initialization data for the superknowa-ext-byom extension.
 */
const plugin = {
    id: 'superknowa-ext-byom:plugin',
    description: 'Superknowa BYOM Jupyterlab extension to provsion a development environment',
    autoStart: true,
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher],
    activate: (app, launcher) => {
        console.log('JupyterLab extension superknowa-ext-byom is being activated!');
        const { commands } = app;
        const command = CommandIDs.create;
        commands.addCommand(command, {
            caption: 'Bring your own model superknowa byom',
            label: 'Superknowa BYOM',
            icon: args => (args['isPalette'] ? undefined : _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.listIcon),
            execute: () => {
                const content = new _widget__WEBPACK_IMPORTED_MODULE_3__.GPUProvisionWidget();
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.title.label = 'Superknowa BYOM';
                widget.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.listIcon;
                app.shell.add(widget, 'main');
            }
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_4__.requestAPI)('get-example')
            .then(data => {
            console.log(data);
        })
            .catch(reason => {
            console.error(`The superknowa_ext_byom server extension appears to be missing.\n${reason}`);
        });
        if (launcher) {
            launcher.add({
                command
            });
        }
        console.log('JupyterLab extension superknowa-ext-byom is activated!');
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/widget.js":
/*!***********************!*\
  !*** ./lib/widget.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GPUProvisionWidget: () => (/* binding */ GPUProvisionWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/VisibilityOff */ "./node_modules/@mui/icons-material/VisibilityOff.js");
/* harmony import */ var _mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Visibility */ "./node_modules/@mui/icons-material/Visibility.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _IBMIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./IBMIcon */ "./lib/IBMIcon.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _mui_icons_material_RefreshOutlined__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/RefreshOutlined */ "./node_modules/@mui/icons-material/RefreshOutlined.js");
/* harmony import */ var _mui_icons_material_RemoveCircleOutlineOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/icons-material/RemoveCircleOutlineOutlined */ "./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js");
/* harmony import */ var _mui_icons_material_StorageOutlined__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/StorageOutlined */ "./node_modules/@mui/icons-material/StorageOutlined.js");










/**
 * React component for a counter.
 *
 * @returns The React component
 */
const GPUProvisionComponent = () => {
    const [showPassword, setShowPassword] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [showPat, setShowPat] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [ibmApiKey, setIbmApiKey] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [githubPAT, setGithubPAT] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [vpc_vsi_profile_name, setVpc_vsi_profile_name] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('gx2-8x64x1v100');
    const [vpc_vsi_image_name, setVpc_vsi_image_name] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('ibm-ubuntu-22-04-3-minimal-amd64-1');
    const [region, setRegion] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('eu-gb');
    const [zone, setZone] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('eu-gb-1');
    const [ssh_key_name, setSsh_key_name] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [server_details, setServer_details] = react__WEBPACK_IMPORTED_MODULE_2___default().useState('');
    const [provisionInProgress, setProvisionInProgress] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [checkStatusInProgress, setCheckStatusInProgress] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const [submitStatus, setSubmitStatus] = react__WEBPACK_IMPORTED_MODULE_2___default().useState({
        status: '',
        message: ''
    });
    const handleClickShowPassword = () => setShowPassword(show => !show);
    const handleClickShowGithubPAT = () => setShowPat(show => !show);
    const [openRemoveWorkspaceAgree, setOpenRemoveWorkspaceAgree] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const handleRemoveWorkspaceOpen = () => {
        setOpenRemoveWorkspaceAgree(true);
    };
    const handleRemoveWorkspaceClose = () => {
        setOpenRemoveWorkspaceAgree(false);
    };
    const [openCreateWorkspaceAgree, setOpenCreateWorkspaceAgree] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const handleCreateWorkspaceOpen = () => {
        setOpenCreateWorkspaceAgree(true);
    };
    const handleCreateWorkspaceClose = () => {
        setOpenCreateWorkspaceAgree(false);
    };
    const region_zone = [
        {
            label: 'Americas',
            region: [
                {
                    label: 'Dallas',
                    value: 'us-south',
                    zone: ['us-south-1', 'us-south-2', 'us-south-3']
                },
                {
                    label: 'Sao Paulo',
                    value: 'br-sao',
                    zone: ['br-sao-1', 'br-sao-2', 'br-sao-3']
                },
                {
                    label: 'Toronto',
                    value: 'ca-tor',
                    zone: ['ca-tor-1', 'ca-tor-2', 'ca-tor-3']
                },
                {
                    label: 'Washington DC',
                    value: 'us-east',
                    zone: ['us-east-1', 'us-east-2', 'us-east-3']
                }
            ]
        },
        {
            label: 'Europe',
            region: [
                {
                    label: 'Frankfurt',
                    value: 'eu-de',
                    zone: ['eu-de-1', 'eu-de-2', 'eu-de-3']
                },
                {
                    label: 'London',
                    value: 'eu-gb',
                    zone: ['eu-gb-1', 'eu-gb-2', 'eu-gb-3']
                },
                {
                    label: 'Madrid',
                    value: 'eu-es',
                    zone: ['eu-es-1', 'eu-es-2', 'eu-es-3']
                }
            ]
        },
        {
            label: 'Asia Pacific',
            region: [
                {
                    label: 'Sydney',
                    value: 'au-syd',
                    zone: ['au-syd-1', 'au-syd-2', 'au-syd-3']
                },
                {
                    label: 'Tokyo',
                    value: 'jp-tok',
                    zone: ['jp-tok-1', 'jp-tok-2', 'jp-tok-3']
                }
            ]
        }
    ];
    const handleProvisionClick = async () => {
        setOpenCreateWorkspaceAgree(false);
        setSubmitStatus({
            status: '',
            message: ''
        });
        if (!ibmApiKey) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid ibm api key'
            });
            return;
        }
        if (!githubPAT) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid github personal access token'
            });
            return;
        }
        if (!zone) {
            setSubmitStatus({
                status: 'error',
                message: 'Please select a valid zone'
            });
            return;
        }
        if (!ssh_key_name) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid ssh key'
            });
            return;
        }
        setProvisionInProgress(true);
        const init = {};
        init.method = 'post';
        init.body = JSON.stringify({
            ibm_iam_token: ibmApiKey,
            githubPAT: githubPAT,
            vpc_vsi_profile_name,
            vpc_vsi_image_name,
            region,
            zone,
            ssh_key_name
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('workspace', init)
            .then(data => {
            if (data.type === 'existing') {
                setSubmitStatus({
                    status: 'success',
                    message: 'A  workspace is already exist'
                });
            }
            else if (data.type === 'new') {
                setSubmitStatus({
                    status: 'success',
                    message: 'Successfully submitted request, it will take some time to complete the request. Please hit the refresh button to get the latest status'
                });
            }
            setWorkspaceStatusResponse({
                id: data.data.id,
                name: data.data.name,
                status: data.data.status,
                variablestore: data.data.template_data[0].variablestore
            });
            setProvisionInProgress(false);
        })
            .catch(reason => {
            setSubmitStatus({
                status: 'error',
                message: `The superknowa_ext_byom server extension appears to be missing.\n${reason}`
            });
            console.error(`Error in creating new workspace. Please contact administrator to resolve the issue.\n${reason}`);
            setProvisionInProgress(false);
        });
    };
    const [workspaceStatusResponse, setWorkspaceStatusResponse] = react__WEBPACK_IMPORTED_MODULE_2___default().useState({
        id: '',
        name: '',
        status: '',
        variablestore: [
            {
                name: '',
                value: ''
            }
        ]
    });
    const handleWorkspaceStatus = async () => {
        const init = {};
        init.method = 'post';
        setSubmitStatus({
            status: '',
            message: ''
        });
        if (!ibmApiKey) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid ibm api key'
            });
            return;
        }
        setCheckStatusInProgress(true);
        init.body = JSON.stringify({
            ibm_iam_token: ibmApiKey
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('wstatus', init)
            .then(data => {
            if (data.status === 'success') {
                setWorkspaceStatusResponse({
                    id: data.data.id,
                    name: data.data.name,
                    status: data.data.status,
                    variablestore: data.data.template_data[0].variablestore
                });
            }
            else {
                setSubmitStatus({
                    status: 'error',
                    message: data.message
                });
                setWorkspaceStatusResponse({
                    id: 'Not found',
                    name: 'Not found',
                    status: 'Unknown',
                    variablestore: []
                });
            }
            setCheckStatusInProgress(false);
        })
            .catch(reason => {
            const response = {
                id: 'Not found',
                name: 'Not found',
                status: 'Unknown',
                variablestore: []
            };
            setWorkspaceStatusResponse(response);
            console.error('Error in getting workspace status. Workspace may not exist.');
            setCheckStatusInProgress(false);
        });
    };
    const handleServerStatus = async () => {
        const init = {};
        init.method = 'post';
        setSubmitStatus({
            status: '',
            message: ''
        });
        if (!ibmApiKey) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid ibm api key'
            });
            return;
        }
        setCheckStatusInProgress(true);
        init.body = JSON.stringify({
            ibm_iam_token: ibmApiKey
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('serverstatus', init)
            .then(data => {
            if (data.status === 'success') {
                setServer_details(JSON.stringify(data));
            }
            else {
                setSubmitStatus({
                    status: 'error',
                    message: data.message
                });
            }
            setCheckStatusInProgress(false);
        })
            .catch(reason => {
            console.error(reason);
            setSubmitStatus({
                status: 'error',
                message: 'Error in getting server details. Server might not exist'
            });
            setCheckStatusInProgress(false);
        });
    };
    const handleDeleteWorkspace = async () => {
        setOpenRemoveWorkspaceAgree(false);
        const init = {};
        init.method = 'post';
        setSubmitStatus({
            status: '',
            message: ''
        });
        if (!ibmApiKey) {
            setSubmitStatus({
                status: 'error',
                message: 'Please enter a valid ibm api key'
            });
            return;
        }
        setCheckStatusInProgress(true);
        init.body = JSON.stringify({
            ibm_iam_token: ibmApiKey
        });
        (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('wdelete', init)
            .then(data => {
            if (data.status === 'success') {
                setSubmitStatus({
                    status: 'success',
                    message: 'Workspace is being deleted. Click on the check status button to get latest status'
                });
                //setWorkspaceStatusResponse(response);
            }
            else {
                setSubmitStatus({
                    status: 'error',
                    message: data.message
                });
            }
            setCheckStatusInProgress(false);
        })
            .catch(reason => {
            const response = {
                id: 'Deleting..',
                name: 'Deleting..',
                status: 'Deletion in progress',
                variablestore: []
            };
            setWorkspaceStatusResponse(response);
            console.error(`Error in deleting workspace status.\n${reason}`);
            setCheckStatusInProgress(false);
        });
    };
    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const handleMouseDownShowPat = (event) => {
        event.preventDefault();
    };
    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', justifyContent: 'center' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_IBMIcon__WEBPACK_IMPORTED_MODULE_4__["default"], null)),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { mt: '12px', variant: "h5", height: '30px', noWrap: true, sx: {
                    display: { xs: 'none', md: 'flex' },
                    fontWeight: 500,
                    textDecoration: 'none'
                } }, "Ecosystem Engineering")),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', justifyContent: 'center' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { mt: '5px', height: '30px', noWrap: true, sx: {
                    display: { xs: 'none', md: 'flex' },
                    fontWeight: 500,
                    textDecoration: 'none'
                } }, "Superknowa BYOM")),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', mt: '50px', flexDirection: 'row', alignContent: 'center', justifyContent: 'center' },
            submitStatus.status === 'success' && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { sx: { marginBottom: '20px' }, variant: "outlined", severity: "success" }, submitStatus.message)),
            submitStatus.status === 'error' && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Alert, { sx: { marginBottom: '20px' }, variant: "outlined", severity: "error" }, submitStatus.message))),
        checkStatusInProgress && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row', alignContent: 'center', justifyContent: 'center', ml: '50px', mr: '50px' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.LinearProgress, { sx: { width: '100%' }, color: "success" }))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', ml: '50px', mr: '50px', flexDirection: 'row', justifyContent: 'space-between' },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: { width: '49%' } },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardHeader, { titleTypographyProps: { variant: 'subtitle1' }, title: "Provision a GPU server for training, inference, and deploying an LLM model." }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', margin: '5px', flexDirection: 'column' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '60ch' }, variant: "outlined" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "outlined-adornment-password", sx: { fontSize: '14px' } }, "Api key"),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.OutlinedInput, { margin: "dense", sx: { height: '40px' }, id: "outlined-adornment-password", type: showPassword ? 'text' : 'password', endAdornment: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { "aria-label": "toggle password visibility", onClick: handleClickShowPassword, onMouseDown: handleMouseDownPassword, edge: "end" }, showPassword ? react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_5__["default"], null) : react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6__["default"], null))), label: "Api Key", onChange: e => {
                                    e.preventDefault();
                                    setIbmApiKey(e.target.value);
                                } })),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '60ch', mt: '10px' }, variant: "outlined" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "outlined-adornment-github", sx: { fontSize: '14px' } }, "Github access token"),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.OutlinedInput, { margin: "dense", sx: { height: '40px' }, id: "outlined-adornment-github", type: showPat ? 'text' : 'password', endAdornment: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputAdornment, { position: "end" },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { "aria-label": "toggle password visibility", onClick: handleClickShowGithubPAT, onMouseDown: handleMouseDownShowPat, edge: "end" }, showPat ? react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_VisibilityOff__WEBPACK_IMPORTED_MODULE_5__["default"], null) : react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_Visibility__WEBPACK_IMPORTED_MODULE_6__["default"], null))), label: "Github access token", onChange: e => {
                                    e.preventDefault();
                                    setGithubPAT(e.target.value);
                                } })),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row', marginTop: '15px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { minWidth: 120 } },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { htmlFor: "region-group-select", sx: { fontSize: '14px' } }, "Region"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, native: true, defaultValue: "", id: "region-group-select", label: "Region", value: region, onChange: e => {
                                        e.preventDefault();
                                        setRegion(e.target.value);
                                        setZone('');
                                    } },
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement("option", { "aria-label": "None", value: "" }),
                                    region_zone.map((reg, _inx) => {
                                        return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("optgroup", { key: _inx, label: reg.label }, reg.region.map((reg_name, _rinx) => {
                                            return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement("option", { key: _rinx, value: reg_name.value }, reg_name.label));
                                        })));
                                    }))),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '150px', marginLeft: '10px' }, variant: "outlined" },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "zone-select-label", sx: { fontSize: '14px' } }, "Zone"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, labelId: "zone-select-label", id: "zone-simple-select", value: zone, label: "Zone", onChange: e => {
                                        setZone(e.target.value);
                                    } }, region_zone
                                    .flatMap(reg => reg.region)
                                    .filter(zn => zn.value === region)
                                    .flatMap(item => item.zone)
                                    .map((fzone, _inx) => {
                                    return (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { key: _inx, value: fzone }, fzone));
                                })))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '50ch', marginTop: '15px' }, variant: "outlined" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "image-vsi-select-label", sx: { fontSize: '14px' } }, "VPC VSI Image Name"),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, labelId: "image-vsi-select-label", id: "demo-simple-select", value: vpc_vsi_image_name, label: "VPC GPU Profile", onChange: e => {
                                    setVpc_vsi_image_name(e.target.value);
                                } },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-22-04-3-minimal-amd64-1' }, "ibm-ubuntu-22-04-3-minimal-amd64-1"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-22-04-3-minimal-amd64-2' }, "ibm-ubuntu-22-04-3-minimal-amd64-2"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'ibm-ubuntu-20-04-6-minimal-amd64-3' }, "ibm-ubuntu-20-04-6-minimal-amd64-3"))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, { sx: { width: '50ch', marginTop: '15px' }, variant: "outlined" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.InputLabel, { id: "demo-simple-select-label", sx: { fontSize: '14px' } }, "VPC GPU Profile"),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Select, { sx: { height: '40px', fontSize: '14px' }, labelId: "demo-simple-select-label", id: "demo-simple-select", value: vpc_vsi_profile_name, label: "VPC GPU Profile", onChange: e => {
                                    setVpc_vsi_profile_name(e.target.value);
                                } },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'gx2-8x64x1v100' }, "gx2-8x64x1v100"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'gx2-16x128x1v100' }, "gx2-16x128x1v100"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'gx2-16x128x2v100' }, "gx2-16x128x2v100"),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.MenuItem, { value: 'gx2-32x256x2v100' }, "gx2-32x256x2v100"))),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, { margin: "dense", sx: {
                                width: '40ch',
                                marginTop: '15px'
                            }, id: "outlined-multiline-flexible", label: "ssh key name", value: ssh_key_name, onChange: e => setSsh_key_name(e.target.value), inputProps: {
                                style: {
                                    height: 10
                                }
                            } }),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { fontSize: '12px', color: 'red', fontStyle: 'italic' }, "Please make sure you write correct ssh key based on the region you selected above, otherwise you will not be able to access the VM after it provisioned.")))),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardActions, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { marginTop: '15px', display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { disabled: provisionInProgress, variant: "outlined", size: "small", onClick: handleCreateWorkspaceOpen, sx: { fontSize: '14px', mr: '10px' } }, "Provision"),
                        provisionInProgress && react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CircularProgress, null)))),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: { width: '49%' } },
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardHeader, { titleTypographyProps: { variant: 'subtitle1' }, title: "Workspace details" }),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardActions, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Click the button to get latest workspace status" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_RefreshOutlined__WEBPACK_IMPORTED_MODULE_7__["default"], null), onClick: handleWorkspaceStatus, sx: { mr: '20px' }, size: "small" }, "Check workspace status")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Click the button to get latest server details" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_StorageOutlined__WEBPACK_IMPORTED_MODULE_8__["default"], null), onClick: handleServerStatus, sx: { mr: '20px' }, size: "small" }, "Check server status")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tooltip, { title: "Delete the GPU server instance" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { variant: "outlined", startIcon: react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_icons_material_RemoveCircleOutlineOutlined__WEBPACK_IMPORTED_MODULE_9__["default"], null), onClick: handleRemoveWorkspaceOpen, size: "small" }, "Remove")))),
                workspaceStatusResponse.id && (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, null,
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Id:")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.id))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Name:")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.name))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: 'flex', flexDirection: 'row' },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { sx: { fontWeight: 'bold' } }, "Workspace Status:")),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mr: '10px' },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, null, workspaceStatusResponse.status))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableContainer, { component: _mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper },
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Table, { size: "small", "aria-label": "Variable details" },
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableHead, null,
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, null,
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Name"),
                                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, "Value"))),
                            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableBody, null, workspaceStatusResponse.variablestore.map(row => (react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableRow, { key: row.name, sx: {
                                    '&:last-child td, &:last-child th': { border: 0 }
                                } },
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, row.name),
                                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TableCell, null, row.value))))))),
                    react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, null,
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "h6", mb: '5px', mt: '10px' }, "Server Details"),
                        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { border: '1px dashed black', borderRadius: '8px', padding: '5px' }, server_details)))))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: openRemoveWorkspaceAgree, onClose: handleRemoveWorkspaceClose, "aria-labelledby": "alert-dialog-remove-workspace-title", "aria-describedby": "alert-dialog-remove-workspace-description" },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, { id: "alert-dialog-create-workspace-title" }, 'Are you sure want to remove this GPU server?'),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContentText, { id: "alert-dialog-create-workspace-description" }, "This action will delete the workspace and the GPU server. All of the resources will be removed and cannot be rolled back.")),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleRemoveWorkspaceClose }, "No"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleDeleteWorkspace, autoFocus: true }, "Yes"))),
        react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: openCreateWorkspaceAgree, onClose: handleRemoveWorkspaceClose, "aria-labelledby": "alert-dialog-title", "aria-describedby": "alert-dialog-create-workspace" },
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, { id: "alert-dialog-create-workspace-title" }, 'Are you sure want to create this GPU server?'),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContentText, { id: "alert-dialog-create-workspace-description" }, "There will be a cost associated with this enviroment. Please review IBM cloud docs for more information.")),
            react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, null,
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleCreateWorkspaceClose }, "No"),
                react__WEBPACK_IMPORTED_MODULE_2___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleProvisionClick, autoFocus: true }, "Yes")))));
};
/**
 * A Counter Lumino Widget that wraps a GPUProvisionComponent.
 */
class GPUProvisionWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    /**
     * Constructs a new GPUProvisionWidget.
     */
    constructor() {
        super();
        this.addClass('jp-react-widget');
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_2___default().createElement(GPUProvisionComponent, null);
    }
}


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/***/ ((module) => {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}
module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@mui/icons-material/RefreshOutlined.js":
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/RefreshOutlined.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z"
}), 'RefreshOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@mui/icons-material/RemoveCircleOutlineOutlined.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M7 11v2h10v-2zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8"
}), 'RemoveCircleOutlineOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/StorageOutlined.js":
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/StorageOutlined.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M2 20h20v-4H2zm2-3h2v2H4zM2 4v4h20V4zm4 3H4V5h2zm-4 7h20v-4H2zm2-3h2v2H4z"
}), 'StorageOutlined');

/***/ }),

/***/ "./node_modules/@mui/icons-material/Visibility.js":
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/Visibility.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5M12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5m0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3"
}), 'Visibility');

/***/ }),

/***/ "./node_modules/@mui/icons-material/VisibilityOff.js":
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/VisibilityOff.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

"use client";

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = void 0;
var _createSvgIcon = _interopRequireDefault(__webpack_require__(/*! ./utils/createSvgIcon */ "./node_modules/@mui/icons-material/utils/createSvgIcon.js"));
var _jsxRuntime = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
var _default = exports["default"] = (0, _createSvgIcon.default)( /*#__PURE__*/(0, _jsxRuntime.jsx)("path", {
  d: "M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7M2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2m4.31-.78 3.15 3.15.02-.16c0-1.66-1.34-3-3-3z"
}), 'VisibilityOff');

/***/ }),

/***/ "./node_modules/@mui/icons-material/utils/createSvgIcon.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/utils/createSvgIcon.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

'use client';

Object.defineProperty(exports, "__esModule", ({
  value: true
}));
Object.defineProperty(exports, "default", ({
  enumerable: true,
  get: function () {
    return _utils.createSvgIcon;
  }
}));
var _utils = __webpack_require__(/*! @mui/material/utils */ "./node_modules/@mui/material/utils/index.js");

/***/ })

}]);
//# sourceMappingURL=lib_index_js.db590881000776d2ca88.js.map